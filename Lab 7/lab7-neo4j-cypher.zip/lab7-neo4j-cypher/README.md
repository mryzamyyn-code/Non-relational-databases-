# Лабораторная работа № 7. Создание графовой модели Neo4j и запросов Cypher

**Дисциплина:** Проектирование и применение NoSQL-технологий
**Вариант 2:** Социальная сеть — узлы `User`, `Post`, `Topic`; отношения `FOLLOWS`, `CREATED`, `INTERESTED_IN` (+ `ABOUT`, `LIKED`)
**Повышенное задание:** рекомендации через связи друзей и интересы (запросы Q5, Q9, Q10)

Все данные синтетические (учебные), реальных персональных данных нет. Пароли и URI в репозиторий не публикуются.

## Структура репозитория

```
lab7-neo4j-cypher/
├── README.md                    ← вы здесь
├── report/Отчет_ЛР7_Neo4j_Cypher.docx   ← отчёт
├── cypher/
│   ├── 01_constraints.cypher    ← уникальные ограничения и индекс
│   ├── 02_create_data.cypher    ← 22 узла, 52 отношения (MERGE, идемпотентно)
│   ├── 03_check_structure.cypher← проверка количества узлов/отношений
│   ├── 04_queries.cypher        ← 10 запросов Q1–Q10
│   ├── 05_update.cypher         ← изменение свойств узла и отношения
│   ├── 06_delete.cypher         ← безопасное удаление тестовых элементов
│   └── 99_reset_lab_db.cypher   ← очистка учебной БД (закомментирована)
├── docs/
│   ├── schema.png               ← схема графа
│   ├── graph_data.png           ← визуализация загруженных данных
│   └── expected_results.md      ← ожидаемые результаты каждого запроса
├── screenshots/                 ← скриншоты результатов из Neo4j Browser
├── docker-compose.yml
├── .env.example
└── run_all.sh
```

## Схема графа

![Схема графа](docs/schema.png)

```mermaid
graph LR
  U1((User)) -- FOLLOWS --> U2((User))
  U1 -- CREATED --> P[Post]
  U1 -- LIKED --> P
  U1 -- INTERESTED_IN --> T{{Topic}}
  P -- ABOUT --> T
```

Пример пути: `(aruzhan)-[:FOLLOWS]->(dias)-[:FOLLOWS]->(madina)-[:CREATED]->(post 109)-[:ABOUT]->(NoSQL)`

| Метка | Узлов | Уникальный идентификатор |
|---|---|---|
| User | 8 | `userId`, `username` |
| Post | 9 | `postId` |
| Topic | 5 | `name` |

| Отношение | Направление | Кол-во |
|---|---|---|
| FOLLOWS | User → User | 12 |
| CREATED | User → Post | 9 |
| INTERESTED_IN | User → Topic | 13 |
| ABOUT | Post → Topic | 10 |
| LIKED | User → Post | 8 |

## Как запустить

### Вариант A — Neo4j Desktop / AuraDB Free
1. Создайте учебную БД и откройте Neo4j Browser (Query).
2. По очереди вставьте и выполните файлы `cypher/01…06` (в Browser должен быть включён multi-statement editor — по умолчанию включён).

### Вариант B — Docker
```bash
cp .env.example .env            # задайте свой пароль в .env
docker compose up -d
# откройте http://localhost:7474 (логин neo4j, пароль из .env)
export NEO4J_PASSWORD=...        # тот же пароль
./run_all.sh                     # выполнит все скрипты через cypher-shell
```
Проверка соединения: `RETURN 'Neo4j works' AS status;`

## Запросы

| № | Тип | Назначение |
|---|---|---|
| Q1 | Простое MATCH | Список всех пользователей |
| Q2 | Фильтрация (WHERE) | Популярные посты за октябрь 2026 (≥ 20 лайков) |
| Q3 | Сортировка и ограничение (ORDER BY / LIMIT) | Топ-3 поста по количеству лайков |
| Q4 | Запрос по отношению | На кого подписана пользователь aruzhan |
| Q5 | Двухшаговый обход | Рекомендация «на кого подписаться» (друзья друзей) |
| Q6 | Обход переменной длины (1..3) | Охват сети aruzhan до 3 переходов |
| Q7 | Агрегирование count() | Количество подписчиков у каждого пользователя |
| Q8 | Агрегирование count() + sum() | Активность по темам |
| Q9 | Повышенное: рекомендации через связи и интересы | Рекомендация постов для aruzhan |
| Q10 | Повышенное: рекомендации тем | Новые темы через интересы подписок |

Ожидаемые результаты — в [docs/expected_results.md](docs/expected_results.md).

## Скриншоты результатов

**RETURN 'Neo4j works' AS status;**

![01_connection.png](screenshots/01_connection.png)

**SHOW CONSTRAINTS после 01_constraints.cypher**

![02_constraints.png](screenshots/02_constraints.png)

**количество узлов по меткам**

![03_structure_nodes.png](screenshots/03_structure_nodes.png)

**количество отношений по типам**

![04_structure_rels.png](screenshots/04_structure_rels.png)

**граф целиком в Neo4j Browser (MATCH (n)-[r]->(m) RETURN n,r,m)**

![05_graph.png](screenshots/05_graph.png)

**Q1: Список всех пользователей**

![q1.png](screenshots/q1.png)

**Q2: Популярные посты за октябрь 2026 (≥ 20 лайков)**

![q2.png](screenshots/q2.png)

**Q3: Топ-3 поста по количеству лайков**

![q3.png](screenshots/q3.png)

**Q4: На кого подписана пользователь aruzhan**

![q4.png](screenshots/q4.png)

**Q5: Рекомендация «на кого подписаться» (друзья друзей)**

![q5.png](screenshots/q5.png)

**Q6: Охват сети aruzhan до 3 переходов**

![q6.png](screenshots/q6.png)

**Q7: Количество подписчиков у каждого пользователя**

![q7.png](screenshots/q7.png)

**Q8: Активность по темам**

![q8.png](screenshots/q8.png)

**Q9: Рекомендация постов для aruzhan**

![q9.png](screenshots/q9.png)

**Q10: Новые темы через интересы подписок**

![q10.png](screenshots/q10.png)

**5.1 состояние до изменения**

![u1_before.png](screenshots/u1_before.png)

**5.4–5.5 контрольные запросы после изменения**

![u2_after.png](screenshots/u2_after.png)

**6.2 проверка перед удалением**

![d1_before_delete.png](screenshots/d1_before_delete.png)

**6.5 контроль после удаления**

![d2_after_delete.png](screenshots/d2_after_delete.png)

