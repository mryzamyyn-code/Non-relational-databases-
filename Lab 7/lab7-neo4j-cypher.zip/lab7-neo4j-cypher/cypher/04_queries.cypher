// ЛР7. Шаг 4. Запросы Cypher (выполнять по одному, результат — в скриншоты)

// Q1. Простое MATCH: Список всех пользователей
MATCH (u:User)
RETURN u.userId AS id, u.username AS username, u.city AS city
ORDER BY id;

// Q2. Фильтрация (WHERE): Популярные посты за октябрь 2026 (≥ 20 лайков)
MATCH (a:User)-[:CREATED]->(p:Post)
WHERE p.likes >= 20 AND p.createdAt >= date('2026-10-01')
RETURN p.postId AS postId, a.username AS author, p.text AS text, p.likes AS likes
ORDER BY likes DESC;

// Q3. Сортировка и ограничение (ORDER BY / LIMIT): Топ-3 поста по количеству лайков
MATCH (p:Post)
RETURN p.postId AS postId, p.text AS text, p.likes AS likes
ORDER BY likes DESC
LIMIT 3;

// Q4. Запрос по отношению: На кого подписана пользователь aruzhan
MATCH (:User {username:'aruzhan'})-[f:FOLLOWS]->(u:User)
RETURN u.username AS following, u.city AS city, f.since AS since
ORDER BY since;

// Q5. Двухшаговый обход: Рекомендация «на кого подписаться» (друзья друзей)
MATCH (me:User {userId:1})-[:FOLLOWS]->(f:User)-[:FOLLOWS]->(fof:User)
WHERE fof <> me AND NOT (me)-[:FOLLOWS]->(fof)
RETURN fof.username AS recommended,
       count(DISTINCT f) AS mutual,
       collect(DISTINCT f.username) AS via
ORDER BY mutual DESC, recommended;

// Q6. Обход переменной длины (1..3): Охват сети aruzhan до 3 переходов
MATCH p = (me:User {userId:1})-[:FOLLOWS*1..3]->(u:User)
WHERE u <> me
RETURN u.username AS user, min(length(p)) AS hops
ORDER BY hops, user;

// Q7. Агрегирование count(): Количество подписчиков у каждого пользователя
MATCH (u:User)
OPTIONAL MATCH (f:User)-[:FOLLOWS]->(u)
RETURN u.username AS user, count(f) AS followers
ORDER BY followers DESC, user;

// Q8. Агрегирование count() + sum(): Активность по темам
MATCH (t:Topic)
OPTIONAL MATCH (p:Post)-[:ABOUT]->(t)
RETURN t.name AS topic, count(p) AS posts, coalesce(sum(p.likes), 0) AS totalLikes
ORDER BY posts DESC, totalLikes DESC, topic;

// Q9. Повышенное: рекомендации через связи и интересы: Рекомендация постов для aruzhan
MATCH (me:User {userId:1})-[:INTERESTED_IN]->(t:Topic)<-[:ABOUT]-(p:Post)<-[:CREATED]-(author:User)
WHERE author <> me AND NOT (me)-[:LIKED]->(p)
MATCH path = shortestPath((me)-[:FOLLOWS*1..3]->(author))
RETURN p.postId AS postId, p.text AS text, author.username AS author,
       length(path) AS distance, collect(DISTINCT t.name) AS topics, p.likes AS likes
ORDER BY distance, likes DESC;

// Q10. Повышенное: рекомендации тем: Новые темы через интересы подписок
MATCH (me:User {userId:1})-[:FOLLOWS]->(f:User)-[:INTERESTED_IN]->(t:Topic)
WHERE NOT (me)-[:INTERESTED_IN]->(t)
RETURN t.name AS topic, count(DISTINCT f) AS friends, collect(DISTINCT f.username) AS via
ORDER BY friends DESC, topic;
