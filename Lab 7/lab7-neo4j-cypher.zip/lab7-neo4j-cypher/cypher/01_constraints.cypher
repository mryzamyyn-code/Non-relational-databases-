// ЛР7. Шаг 1. Ограничения уникальности и индексы
// Выполнять ДО загрузки данных: MERGE опирается на уникальные идентификаторы.
CREATE CONSTRAINT user_id_unique IF NOT EXISTS
FOR (u:User) REQUIRE u.userId IS UNIQUE;

CREATE CONSTRAINT user_username_unique IF NOT EXISTS
FOR (u:User) REQUIRE u.username IS UNIQUE;

CREATE CONSTRAINT post_id_unique IF NOT EXISTS
FOR (p:Post) REQUIRE p.postId IS UNIQUE;

CREATE CONSTRAINT topic_name_unique IF NOT EXISTS
FOR (t:Topic) REQUIRE t.name IS UNIQUE;

CREATE INDEX post_created_at IF NOT EXISTS
FOR (p:Post) ON (p.createdAt);

SHOW CONSTRAINTS;
