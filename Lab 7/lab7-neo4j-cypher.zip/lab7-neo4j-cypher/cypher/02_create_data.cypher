// ЛР7. Шаг 2. Создание графа «Социальная сеть» (вариант 2)
// Все данные синтетические. Скрипт идемпотентен: MERGE по уникальным ID,
// повторный запуск не создаёт дублей.

// ---------- Узлы: User (8)
UNWIND [
  {userId:1, username:'aruzhan', name:'Aruzhan', city:'Almaty', joined:'2025-09-01'},
  {userId:2, username:'dias', name:'Dias', city:'Astana', joined:'2025-09-03'},
  {userId:3, username:'aigerim', name:'Aigerim', city:'Almaty', joined:'2025-09-05'},
  {userId:4, username:'nurlan', name:'Nurlan', city:'Shymkent', joined:'2025-09-10'},
  {userId:5, username:'madina', name:'Madina', city:'Almaty', joined:'2025-09-12'},
  {userId:6, username:'timur', name:'Timur', city:'Astana', joined:'2025-09-15'},
  {userId:7, username:'dana', name:'Dana', city:'Karaganda', joined:'2025-09-20'},
  {userId:8, username:'yerlan', name:'Yerlan', city:'Almaty', joined:'2025-09-25'}
] AS row
MERGE (u:User {userId: row.userId})
SET u.username = row.username, u.name = row.name,
    u.city = row.city, u.joined = date(row.joined);

// ---------- Узлы: Topic (5)
UNWIND [
  {topicId:1, name:'Python'},
  {topicId:2, name:'NoSQL'},
  {topicId:3, name:'Football'},
  {topicId:4, name:'Music'},
  {topicId:5, name:'Travel'}
] AS row
MERGE (t:Topic {name: row.name})
SET t.topicId = row.topicId;

// ---------- Узлы: Post (9)
UNWIND [
  {postId:101, text:'Первые шаги в Cypher', createdAt:'2026-10-01', likes:15},
  {postId:102, text:'Генераторы в Python', createdAt:'2026-10-03', likes:24},
  {postId:103, text:'Neo4j vs MongoDB: что выбрать', createdAt:'2026-10-05', likes:31},
  {postId:104, text:'Обзор матча Кайрат — Астана', createdAt:'2026-10-06', likes:12},
  {postId:105, text:'Плейлист для учёбы', createdAt:'2026-10-08', likes:19},
  {postId:106, text:'Маршрут по Чарынскому каньону', createdAt:'2026-10-10', likes:27},
  {postId:107, text:'Концерт в Караганде', createdAt:'2026-10-12', likes:8},
  {postId:108, text:'Python для анализа футбольной статистики', createdAt:'2026-10-14', likes:22},
  {postId:109, text:'Индексы в графовых БД', createdAt:'2026-10-16', likes:17}
] AS row
MERGE (p:Post {postId: row.postId})
SET p.text = row.text, p.createdAt = date(row.createdAt), p.likes = row.likes;

// ---------- Отношения: (:User)-[:FOLLOWS {since}]->(:User) (12)
UNWIND [
  [1, 2, '2025-10-01'], [1, 3, '2025-10-02'], [2, 4, '2025-10-05'],
  [2, 5, '2025-10-06'], [3, 5, '2025-10-08'], [3, 6, '2025-10-09'],
  [4, 7, '2025-10-12'], [5, 8, '2025-10-15'], [6, 1, '2025-10-18'],
  [7, 8, '2025-10-20'], [8, 2, '2025-10-22'], [5, 1, '2025-10-25']
] AS row
MATCH (a:User {userId: row[0]}), (b:User {userId: row[1]})
MERGE (a)-[f:FOLLOWS]->(b)
SET f.since = date(row[2]);

// ---------- Отношения: (:User)-[:CREATED]->(:Post) (9)
UNWIND [
  [1, 101], [2, 102], [3, 103], [4, 104], [5, 105],
  [6, 106], [7, 107], [8, 108], [5, 109]
] AS row
MATCH (u:User {userId: row[0]}), (p:Post {postId: row[1]})
MERGE (u)-[:CREATED]->(p);

// ---------- Отношения: (:User)-[:INTERESTED_IN {level}]->(:Topic) (13)
UNWIND [
  [1, 'Python', 4], [1, 'NoSQL', 5], [2, 'Python', 5], [2, 'Football', 3],
  [3, 'NoSQL', 4], [3, 'Travel', 3], [4, 'Football', 5], [5, 'Music', 4],
  [5, 'NoSQL', 3], [6, 'Travel', 5], [7, 'Music', 5], [8, 'Python', 3],
  [8, 'Football', 4]
] AS row
MATCH (u:User {userId: row[0]}), (t:Topic {name: row[1]})
MERGE (u)-[i:INTERESTED_IN]->(t)
SET i.level = row[2];

// ---------- Отношения: (:Post)-[:ABOUT]->(:Topic) (10)
UNWIND [
  [101, 'NoSQL'], [102, 'Python'], [103, 'NoSQL'], [104, 'Football'], [105, 'Music'],
  [106, 'Travel'], [107, 'Music'], [108, 'Python'], [108, 'Football'], [109, 'NoSQL']
] AS row
MATCH (p:Post {postId: row[0]}), (t:Topic {name: row[1]})
MERGE (p)-[:ABOUT]->(t);

// ---------- Отношения: (:User)-[:LIKED {at}]->(:Post) (8)
UNWIND [
  [1, 102, '2026-10-04'], [1, 103, '2026-10-06'], [2, 108, '2026-10-15'],
  [3, 101, '2026-10-02'], [5, 103, '2026-10-07'], [6, 103, '2026-10-07'],
  [8, 102, '2026-10-05'], [4, 108, '2026-10-16']
] AS row
MATCH (u:User {userId: row[0]}), (p:Post {postId: row[1]})
MERGE (u)-[l:LIKED]->(p)
SET l.at = date(row[2]);
