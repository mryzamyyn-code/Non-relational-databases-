// ЛР7. Шаг 6. Безопасное удаление (только тестовые элементы!)

// 6.1 Создаём тестовый узел и две тестовые связи
MERGE (t:User {userId:999})
SET t.username = 'test_bot', t.name = 'Test Bot', t.city = 'Test', t.isTest = true
WITH t
MATCH (a:User {userId:1}), (p:Post {postId:101})
MERGE (t)-[:FOLLOWS {since: date('2026-11-01')}]->(a)
MERGE (t)-[:LIKED {at: date('2026-11-01')}]->(p);

// 6.2 ПРОВЕРКА перед удалением: что именно будет удалено
MATCH (t:User {userId:999, isTest:true})-[r]->(x)
RETURN t.username AS node, type(r) AS rel,
       coalesce(x.username, toString(x.postId)) AS target;

// 6.3 Удаление ОДНОЙ тестовой связи (LIKED test_bot -> 101)
//     сначала показать её...
MATCH (:User {userId:999})-[r:LIKED]->(p:Post {postId:101})
RETURN type(r) AS rel, p.postId AS post;
//     ...затем удалить
MATCH (:User {userId:999})-[r:LIKED]->(:Post {postId:101})
DELETE r;
//     контроль: 0
MATCH (:User {userId:999})-[r:LIKED]->(:Post {postId:101})
RETURN count(r) AS remaining;

// 6.4 Удаление тестового узла вместе с оставшимися связями
MATCH (t:User {userId:999, isTest:true})
RETURN t;
MATCH (t:User {userId:999, isTest:true})
DETACH DELETE t;

// 6.5 Контроль: узла больше нет (0), основной граф не пострадал (22 / 52)
MATCH (t:User {userId:999}) RETURN count(t) AS testUsers;
MATCH (n) WITH count(n) AS nodes
MATCH ()-[r]->() RETURN nodes, count(r) AS relationships;
