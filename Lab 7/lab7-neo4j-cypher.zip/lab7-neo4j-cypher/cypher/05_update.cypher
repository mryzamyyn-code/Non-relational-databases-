// ЛР7. Шаг 5. Изменение данных

// 5.1 Состояние ДО изменения  -> dana | Karaganda
MATCH (u:User {userId:7})
RETURN u.username AS user, u.city AS city;

// 5.2 Изменение свойства узла: пользователь dana переехала в Алматы
MATCH (u:User {userId:7})
SET u.city = 'Almaty', u.updatedAt = datetime()
RETURN u.username AS user, u.city AS city;

// 5.3 Изменение свойства отношения: aruzhan отмечает aigerim как близкого друга
MATCH (:User {userId:1})-[f:FOLLOWS]->(:User {userId:3})
SET f.closeFriend = true
RETURN type(f) AS rel, f.since AS since, f.closeFriend AS closeFriend;

// 5.4 Контрольный MATCH: dana теперь среди пользователей из Almaty
MATCH (u:User {city:'Almaty'})
RETURN u.username AS user ORDER BY user;

// 5.5 Контрольный MATCH для отношения
MATCH (a:User)-[f:FOLLOWS {closeFriend:true}]->(b:User)
RETURN a.username AS from, b.username AS to, f.closeFriend AS closeFriend;
