// ЛР7. Шаг 3. Проверка структуры графа
// Ожидается: User 8, Post 9, Topic 5 (всего 22 узла)
MATCH (n) RETURN labels(n) AS labels, count(*) AS qty ORDER BY qty DESC;

// Ожидается: INTERESTED_IN 13, FOLLOWS 12, ABOUT 10, CREATED 9, LIKED 8 (всего 52)
MATCH ()-[r]->() RETURN type(r) AS relation, count(*) AS qty ORDER BY qty DESC;

// Итоговые количества
MATCH (n) WITH count(n) AS nodes
MATCH ()-[r]->() RETURN nodes, count(r) AS relationships;

// Визуальная проверка всего графа (для скриншота в Neo4j Browser)
MATCH (n)-[r]->(m) RETURN n, r, m;
