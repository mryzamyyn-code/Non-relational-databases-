# Ожидаемые результаты запросов

Рассчитаны независимо (скриптом на Python) по тем же данным, что загружаются в `02_create_data.cypher`. Используйте для сверки со своими скриншотами. Порядок элементов внутри списков `collect()` в Neo4j может отличаться.

## Q1. Список всех пользователей

| id | username | city |
|---|---|---|
| 1 | aruzhan | Almaty |
| 2 | dias | Astana |
| 3 | aigerim | Almaty |
| 4 | nurlan | Shymkent |
| 5 | madina | Almaty |
| 6 | timur | Astana |
| 7 | dana | Karaganda |
| 8 | yerlan | Almaty |

## Q2. Популярные посты за октябрь 2026 (≥ 20 лайков)

| postId | author | text | likes |
|---|---|---|---|
| 103 | aigerim | Neo4j vs MongoDB: что выбрать | 31 |
| 106 | timur | Маршрут по Чарынскому каньону | 27 |
| 102 | dias | Генераторы в Python | 24 |
| 108 | yerlan | Python для анализа футбольной статистики | 22 |

## Q3. Топ-3 поста по количеству лайков

| postId | text | likes |
|---|---|---|
| 103 | Neo4j vs MongoDB: что выбрать | 31 |
| 106 | Маршрут по Чарынскому каньону | 27 |
| 102 | Генераторы в Python | 24 |

## Q4. На кого подписана пользователь aruzhan

| following | city | since |
|---|---|---|
| dias | Astana | 2025-10-01 |
| aigerim | Almaty | 2025-10-02 |

## Q5. Рекомендация «на кого подписаться» (друзья друзей)

| recommended | mutual | via |
|---|---|---|
| madina | 2 | [aigerim, dias] |
| nurlan | 1 | [dias] |
| timur | 1 | [aigerim] |

## Q6. Охват сети aruzhan до 3 переходов

| user | hops |
|---|---|
| aigerim | 1 |
| dias | 1 |
| madina | 2 |
| nurlan | 2 |
| timur | 2 |
| dana | 3 |
| yerlan | 3 |

## Q7. Количество подписчиков у каждого пользователя

| user | followers |
|---|---|
| aruzhan | 2 |
| dias | 2 |
| madina | 2 |
| yerlan | 2 |
| aigerim | 1 |
| dana | 1 |
| nurlan | 1 |
| timur | 1 |

## Q8. Активность по темам

| topic | posts | totalLikes |
|---|---|---|
| NoSQL | 3 | 63 |
| Python | 2 | 46 |
| Football | 2 | 34 |
| Music | 2 | 27 |
| Travel | 1 | 27 |

## Q9. Рекомендация постов для aruzhan

| postId | text | author | distance | topics | likes |
|---|---|---|---|---|---|
| 109 | Индексы в графовых БД | madina | 2 | [NoSQL] | 17 |
| 108 | Python для анализа футбольной статистики | yerlan | 3 | [Python] | 22 |

## Q10. Новые темы через интересы подписок

| topic | friends | via |
|---|---|---|
| Football | 1 | [dias] |
| Travel | 1 | [aigerim] |
