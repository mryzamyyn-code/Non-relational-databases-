#!/usr/bin/env bash
# Последовательно выполняет все скрипты ЛР7 в контейнере neo4j-lab7.
# Использование:  export NEO4J_PASSWORD=...  &&  ./run_all.sh
set -euo pipefail
: "${NEO4J_PASSWORD:?Задайте переменную NEO4J_PASSWORD}"
for f in 01_constraints 02_create_data 03_check_structure 04_queries 05_update 06_delete; do
  echo "===== $f ====="
  docker exec -i neo4j-lab7 cypher-shell -u neo4j -p "$NEO4J_PASSWORD" --format plain -f "/cypher/$f.cypher"
done
