"""
Лабораторная работа №11. Проектирование стратегии шардирования и тест распределения.
Вариант 02 — «Университет».
  * основной кандидат shard key: studentId (hashed);
  * альтернативный низкокардинальный ключ: facultyId;
  * диапазонный кандидат: последовательный eventId (ranged);
  * улучшенные составные ключи (шаг 4):
      (D) {studentId, dayBucket} — hashed;
      (E) {facultyId, studentId} — ranged (facultyId как «tenant»).
Основной запрос — события (посещения, оценки, входы в LMS) одного студента.

Запуск:  python simulation.py
Только стандартная библиотека Python 3.10+. Seed фиксирован => результаты
одинаковы при каждом запуске (см. FINGERPRINT в конце вывода).

ВАЖНО: распределение по модулю и SHA-256 — учебное упрощение,
а не реальный алгоритм чанков/балансировщика MongoDB и маршрутизатора mongos.
"""
import hashlib
import json
import os
import random
from bisect import bisect_right
from collections import Counter

SEED = 42
N, Q, SHARDS = 12000, 30000, 3          # документов, запросов, шардов
STUDENTS = 2500                          # уникальных studentId (>= 1000 по заданию)
FACULTIES = 5                            # уникальных facultyId (низкая кардинальность)
DAYS = 30                                # события за 30 дней семестра
HOT_SHARE = 0.60                         # доля запросов к одному факультету (hot)
SKEW_SHARE = 0.80                        # доля документов одного факультета (шаг 4)
NEW_EVENTS = 3000                        # поток новых вставок (AP-04)
HOT_FACULTY = 0

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


# --------------------------------------------------------------------------
# Генерация данных
# --------------------------------------------------------------------------
def make_base_rows():
    """Базовый набор (как в методичке): facultyId распределён равномерно."""
    return [dict(studentId=i % STUDENTS,
                 facultyId=i % FACULTIES,
                 eventId=i,
                 day=i * DAYS // N) for i in range(N)]


def make_skewed_rows(rng):
    """Шаг 4: один факультет (facultyId=0) содержит 80 % записей."""
    rows = []
    for i in range(N):
        faculty = HOT_FACULTY if rng.random() < SKEW_SHARE else rng.randint(1, FACULTIES - 1)
        rows.append(dict(studentId=i % STUDENTS, facultyId=faculty,
                         eventId=i, day=i * DAYS // N))
    return rows


def make_new_events(start_id):
    """Поток новых событий (AP-04): eventId и day монотонно растут."""
    return [dict(studentId=(start_id + k) % STUDENTS,
                 facultyId=(start_id + k) % FACULTIES,
                 eventId=start_id + k,
                 day=DAYS) for k in range(NEW_EVENTS)]


# --------------------------------------------------------------------------
# Функции размещения (кандидатные shard key)
# --------------------------------------------------------------------------
def stable_hash(value):
    digest = hashlib.sha256(str(value).encode()).digest()
    return int.from_bytes(digest[:8], "big")


def low_card(row):                       # (A) facultyId, ranged/по значению
    return row["facultyId"] % SHARDS


def hashed_student(row):                 # (B) studentId, hashed
    return stable_hash(row["studentId"]) % SHARDS


def range_event(row):                    # (C) eventId, ranged по диапазонам
    return min(row["eventId"] // (N // SHARDS), SHARDS - 1)


def hashed_student_day(row):             # (D) {studentId, dayBucket}, hashed
    return stable_hash(f'{row["studentId"]}|{row["day"]}') % SHARDS


def make_range_faculty_student(rows):
    """(E) {facultyId, studentId}, ranged. Границы диапазонов выбираются
    по квантилям документов (как если бы балансировщик уже разделил чанки
    поровну); значения одной пары никогда не разрываются между шардами."""
    keys = sorted((r["facultyId"], r["studentId"]) for r in rows)
    bounds = [keys[len(keys) * k // SHARDS] for k in range(1, SHARDS)]

    def assign(row):
        return bisect_right(bounds, (row["facultyId"], row["studentId"]))
    return assign


CANDIDATES = [("facultyId", low_card),
              ("hashed_studentId", hashed_student),
              ("range_eventId", range_event)]
IMPROVED = ("hashed_studentId_day", hashed_student_day)


# --------------------------------------------------------------------------
# Метрики
# --------------------------------------------------------------------------
def ratio(a, b):
    return round(a / b, 2) if b else float("inf")


def describe(dataset, name, mode, assign, rows, requests):
    docs = Counter(assign(r) for r in rows)
    load = Counter(assign(r) for r in requests)
    d = [docs[i] for i in range(SHARDS)]
    q = [load[i] for i in range(SHARDS)]
    res = dict(dataset=dataset, key=name, mode=mode, docs=d, queries=q,
               doc_share=[round(x / len(rows) * 100, 1) for x in d],
               query_share=[round(x / len(requests) * 100, 1) for x in q],
               doc_max_mean=ratio(max(d), sum(d) / SHARDS),
               doc_max_min=ratio(max(d), min(d)),
               query_max_mean=ratio(max(q), sum(q) / SHARDS),
               query_max_min=ratio(max(q), min(q)))
    print(f"{dataset:5} {name + '/' + mode:34} docs={d} queries={q} "
          f"doc_max_mean={res['doc_max_mean']} query_max_mean={res['query_max_mean']} "
          f"query_max_min={res['query_max_min']}")
    return res


def make_workloads(rng, rows):
    uniform = rng.choices(rows, k=Q)
    hot_rows = [r for r in rows if r["facultyId"] == HOT_FACULTY]
    hot = [rng.choice(hot_rows) if rng.random() < HOT_SHARE else rng.choice(rows)
           for _ in range(Q)]
    return uniform, hot


def cardinality(rows):
    return {"facultyId": len({r["facultyId"] for r in rows}),
            "studentId": len({r["studentId"] for r in rows}),
            "eventId": len({r["eventId"] for r in rows}),
            "studentId+dayBucket": len({(r["studentId"], r["day"]) for r in rows}),
            "facultyId+studentId": len({(r["facultyId"], r["studentId"]) for r in rows})}


def frequency(rows, field):
    """Частота самого популярного значения ключа (в % от документов)."""
    c = Counter(r[field] for r in rows)
    return round(c.most_common(1)[0][1] / len(rows) * 100, 2)


# --------------------------------------------------------------------------
# Access Patterns: сколько шардов содержат данные, нужные запросу
# --------------------------------------------------------------------------
def access_patterns(rows, rng, improved):
    sid = rng.randrange(STUDENTS)
    day = rng.randrange(DAYS)
    patterns = [
        ("AP-01", "события студента", lambda r: r["studentId"] == sid),
        ("AP-02", "события за интервал дней 10..12", lambda r: 10 <= r["day"] <= 12),
        ("AP-03", "агрегация по факультету", lambda r: r["facultyId"] == 2),
        ("AP-05", "события студента за день", lambda r: r["studentId"] == sid and r["day"] == day),
        ("AP-06", "отчёт факультета за интервал", lambda r: r["facultyId"] == 2 and 10 <= r["day"] <= 12),
    ]
    out = []
    for ap, title, pred in patterns:
        match = [r for r in rows if pred(r)]
        row = dict(ap=ap, title=title, matched=len(match))
        for name, fn in CANDIDATES + improved:
            row[name] = len({fn(r) for r in match})
        out.append(row)
    return out


def insert_stream(rows, improved):
    """AP-04: куда попадают 3000 новых монотонных вставок."""
    new = make_new_events(len(rows))
    out = []
    for name, fn in CANDIDATES + improved:
        c = Counter(fn(r) for r in new)
        out.append(dict(key=name, inserts=[c[i] for i in range(SHARDS)]))
    return out


# --------------------------------------------------------------------------
def main():
    random.seed(SEED)
    results = {"seed": SEED, "N": N, "Q": Q, "SHARDS": SHARDS, "experiments": []}

    # ---- Эксперимент 1: базовый набор, uniform / hot (60 % к facultyId=0)
    print("=== Эксперимент 1: базовый набор (facultyId равномерен) ===")
    base = make_base_rows()
    uni, hot = make_workloads(random.Random(SEED), base)
    improved_base = [IMPROVED, ("range_facultyId_studentId", make_range_faculty_student(base))]
    for name, fn in CANDIDATES + improved_base:
        results["experiments"].append(describe("base", name, "uniform", fn, base, uni))
        results["experiments"].append(describe("base", name, "hot", fn, base, hot))

    # ---- Эксперимент 2 (шаг 4): 80 % документов в facultyId=0
    print("\n=== Эксперимент 2: перекос данных (80 % записей в facultyId=0) ===")
    rng = random.Random(SEED + 1)
    skew = make_skewed_rows(rng)
    uni2, hot2 = make_workloads(rng, skew)
    improved_skew = [IMPROVED, ("range_facultyId_studentId", make_range_faculty_student(skew))]
    for name, fn in CANDIDATES + improved_skew:
        results["experiments"].append(describe("skew", name, "uniform", fn, skew, uni2))
        results["experiments"].append(describe("skew", name, "hot", fn, skew, hot2))

    # ---- Характеристики ключей
    results["cardinality"] = {"base": cardinality(base), "skew": cardinality(skew)}
    results["top_value_share_pct"] = {
        "base": {f: frequency(base, f) for f in ("facultyId", "studentId", "eventId")},
        "skew": {f: frequency(skew, f) for f in ("facultyId", "studentId", "eventId")}}
    results["access_patterns"] = access_patterns(base, random.Random(SEED + 2), improved_base)
    results["insert_stream"] = insert_stream(base, improved_base)

    print("\n=== Кардинальность ключей ===")
    for ds, card in results["cardinality"].items():
        print(ds, card)
    print("Доля самого частого значения, %:", results["top_value_share_pct"])

    print("\n=== Access Patterns: число шардов с нужными данными ===")
    for ap in results["access_patterns"]:
        print(ap)
    print("\n=== AP-04: распределение 3000 новых вставок по шардам ===")
    for ins in results["insert_stream"]:
        print(ins)

    # ---- Сохранение
    os.makedirs(OUT_DIR, exist_ok=True)
    payload = json.dumps(results, ensure_ascii=False, indent=2, sort_keys=True)
    with open(os.path.join(OUT_DIR, "results.json"), "w", encoding="utf-8") as f:
        f.write(payload)
    with open(os.path.join(OUT_DIR, "results.csv"), "w", encoding="utf-8") as f:
        f.write("dataset;key;mode;docs_A;docs_B;docs_C;queries_A;queries_B;queries_C;"
                "doc_max_mean;query_max_mean;query_max_min\n")
        for e in results["experiments"]:
            f.write(";".join(map(str, [e["dataset"], e["key"], e["mode"], *e["docs"],
                                       *e["queries"], e["doc_max_mean"],
                                       e["query_max_mean"], e["query_max_min"]])) + "\n")
    fingerprint = hashlib.sha256(payload.encode()).hexdigest()[:16]
    print(f"\nРезультаты сохранены в {OUT_DIR}")
    print(f"FINGERPRINT={fingerprint}  (одинаков при каждом запуске => воспроизводимо)")


if __name__ == "__main__":
    main()
