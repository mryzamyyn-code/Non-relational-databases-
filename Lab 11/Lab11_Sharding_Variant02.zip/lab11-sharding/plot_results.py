"""
Построение графиков по results/results.json (сначала запустите simulation.py).
Требуется matplotlib:  pip install matplotlib
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
LABELS = {"facultyId": "A: facultyId",
          "hashed_studentId": "B: hash(studentId)",
          "range_eventId": "C: range(eventId)",
          "hashed_studentId_day": "D: hash(studentId,\nday)",
          "range_facultyId_studentId": "E: range(facultyId,\nstudentId)"}
COLORS = ["#2a6fb0", "#e08a2c", "#4c9a52"]


def load_chart(data, dataset, keys, fname, title):
    exps = [e for e in data["experiments"] if e["dataset"] == dataset and e["key"] in keys]
    groups = [(e["key"], e["mode"]) for e in exps]
    fig, ax = plt.subplots(figsize=(13, 5), dpi=150)
    width = 0.26
    for s in range(3):
        xs = [i + (s - 1) * width for i in range(len(exps))]
        ax.bar(xs, [e["query_share"][s] for e in exps], width,
               label=f"Шард {'ABC'[s]}", color=COLORS[s])
    ax.axhline(100 / 3, color="black", linestyle="--", linewidth=1)
    ax.text(-0.45, 100 / 3 + 1.5, "идеал 33,3 %", ha="left", fontsize=8)
    ax.set_xticks(range(len(exps)))
    ax.set_xticklabels([f"{LABELS[k]}\n{m}" for k, m in groups], fontsize=8)
    ax.set_ylabel("Доля запросов, %")
    ax.set_title(title, fontsize=11)
    for i, e in enumerate(exps):
        ax.text(i, max(e["query_share"]) + 2, f"max/mean={e['query_max_mean']}",
                ha="center", fontsize=7.5)
    ax.set_ylim(0, 105)
    ax.legend(fontsize=8, loc="upper right")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(RES, fname))
    plt.close(fig)


def architecture():
    fig, ax = plt.subplots(figsize=(10, 5.2), dpi=150)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")

    def box(x, y, w, h, text, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05",
                                    fc=color, ec="black", lw=1))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=8.5)

    def arrow(x1, y1, x2, y2, color="black", style="-|>", ls="-"):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle=style, color=color, lw=1.4, linestyle=ls))

    box(0.3, 4.6, 2.6, 1.0, "Приложение\n(LMS / деканат)", "#eeeeee")
    box(3.7, 4.6, 2.6, 1.0, "mongos\n(маршрутизатор)", "#cfe2f3")
    box(7.1, 4.6, 2.6, 1.0, "Config servers\n(replica set:\nметаданные чанков)", "#fff2cc")
    arrow(2.9, 5.1, 3.7, 5.1)
    arrow(6.3, 5.1, 7.1, 5.1, style="<|-|>")
    for i, x in enumerate([0.6, 3.7, 6.8]):
        box(x, 0.4, 2.6, 1.7,
            f"Shard {'ABC'[i]}\n(replica set:\nPRIMARY + 2 SECONDARY)\nhash(studentId) ∈ диапазон {i + 1}",
            "#d9ead3")
    # targeted
    arrow(4.6, 4.6, 2.2, 2.1, color="#2a6fb0")
    ax.text(1.2, 3.35, "targeted:\nfind({studentId: 1001})\n→ один шард", color="#2a6fb0", fontsize=8)
    # scatter-gather
    for x in (1.6, 5.0, 8.1):
        arrow(5.4, 4.6, x + 0.2, 2.1, color="#c0392b", ls="--")
    ax.text(6.9, 3.35, "scatter-gather:\naggregate по facultyId\nили по интервалу дат\n→ все шарды, слияние в mongos",
            color="#c0392b", fontsize=8)
    ax.set_title("Архитектура: shard key = { studentId: \"hashed\" }", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(RES, "architecture.png"))
    plt.close(fig)


def main():
    with open(os.path.join(RES, "results.json"), encoding="utf-8") as f:
        data = json.load(f)
    base_keys = ["facultyId", "hashed_studentId", "range_eventId"]
    load_chart(data, "base", base_keys + ["hashed_studentId_day", "range_facultyId_studentId"],
               "chart_load_base.png",
               "Эксперимент 1: доля запросов по шардам (uniform / hot = 60 % к facultyId=0)")
    load_chart(data, "skew", base_keys + ["hashed_studentId_day", "range_facultyId_studentId"],
               "chart_load_skew.png",
               "Эксперимент 2: 80 % документов в facultyId=0 — доля запросов по шардам")
    architecture()
    print("Графики сохранены в", RES)


if __name__ == "__main__":
    main()
