// Лабораторная работа №11, вариант 02 «Университет».
// ДОПОЛНИТЕЛЬНОЕ ЗАДАНИЕ (раздел 6 методички) — только для учебного
// шардированного кластера, настроенного преподавателем. В продуктивной
// системе НЕ выполнять. Подключаться через mongos, а не к отдельному shard mongod:
//   mongosh "mongodb://<host_mongos>:27017" mongo/sharded_cluster_demo.js
// Синтаксис и ограничения зависят от версии MongoDB.

sh.status();

const dbName = "university_lab";
const lab = db.getSiblingDB(dbName);

// 1. Индекс и шардирование новой тестовой коллекции по hashed studentId
lab.events.createIndex({ studentId: "hashed" });
sh.enableSharding(dbName);              // в MongoDB 6.0+ не обязательно
sh.shardCollection(dbName + ".events", { studentId: "hashed" });

// 2. Заполнение синтетикой: 12 000 событий, 2 500 студентов, 5 факультетов
const docs = [];
for (let i = 0; i < 12000; i++) {
  docs.push({
    eventId: i,
    studentId: i % 2500,
    facultyId: i % 5,
    day: Math.floor(i * 30 / 12000),
    type: ["attendance", "grade", "lms_login"][i % 3],
    ts: new Date(Date.UTC(2026, 8, 1) + Math.floor(i * 30 / 12000) * 86400000)
  });
}
lab.events.insertMany(docs);

// 3. Распределение документов по шардам
lab.events.getShardDistribution();      // если недоступно: sh.status() и $collStats

// 4. Targeted-запрос (AP-01): в плане должен участвовать один шард (SINGLE_SHARD)
printjson(lab.events.find({ studentId: 1001 }).explain("executionStats").queryPlanner.winningPlan.stage);

// 5. Scatter-gather (AP-03): агрегация по факультету затрагивает все шарды (SHARD_MERGE)
const agg = lab.events.explain()
  .aggregate([{ $match: { facultyId: 2 } }, { $group: { _id: "$type", n: { $sum: 1 } } }]);
printjson(Object.keys(agg.shards || {}));   // список шардов, к которым обратился mongos
