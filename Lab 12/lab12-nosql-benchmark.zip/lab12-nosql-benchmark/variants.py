"""Двадцать индивидуальных вариантов (раздел 11 методички).

Каждый вариант задаёт коллекцию, два поля фильтра (f1 — первое поле
составного индекса, f2 — второе), их домены значений, значения для
главного запроса AP-01 и дополнительные поля документа.
Вариант 01 полностью совпадает с примером из раздела 4.
"""
import random

STATUS = ["new", "paid", "shipped", "delivered", "cancelled"]
BOOKING = ["pending", "confirmed", "checked_in", "cancelled"]
DELIVERY = ["assigned", "picked_up", "in_transit", "delivered", "failed"]
PRIORITY = ["low", "medium", "high", "critical"]
EVENTS = ["boot", "heartbeat", "alarm", "update", "shutdown", "error"]
VISITS = ["consultation", "checkup", "procedure", "emergency", "followup"]
LEVELS = ["beginner", "intermediate", "advanced", "expert"]
SEASONS = ["spring", "summer", "autumn", "winter"]
MEMBERSHIP = ["basic", "standard", "premium", "vip", "student"]
ZONES = ["vip", "parter", "amphi", "balcony", "fan", "standing"]
STAGES = ["backlog", "analysis", "dev", "review", "testing", "done"]


def r(a, b):
    return {"type": "int", "min": a, "max": b}


def c(values):
    return {"type": "choice", "values": values}


VARIANTS = {
    1:  dict(name="Каталог курсов", collection="courses",
             f1="departmentId", d1=r(1, 20), f2="semester", d2=r(1, 8), q=(10, 5),
             title="Course", extra={"credits": r(2, 6), "teacherId": r(1, 150)}),
    2:  dict(name="Расписание", collection="schedule",
             f1="groupId", d1=r(1, 60), f2="weekday", d2=r(1, 6), q=(30, 3),
             title="Lesson", extra={"pair": r(1, 6), "roomId": r(1, 120)}),
    3:  dict(name="Библиотека", collection="books",
             f1="categoryId", d1=r(1, 25), f2="publishedYear", d2=r(1995, 2025), q=(12, 2015),
             title="Book", extra={"pages": r(50, 900), "authorId": r(1, 400)}),
    4:  dict(name="Заказы магазина", collection="orders",
             f1="customerId", d1=r(1, 500), f2="status", d2=c(STATUS), q=(250, "paid"),
             title="Order", extra={"amount": r(500, 90000), "items": r(1, 10)}),
    5:  dict(name="Бронирование", collection="bookings",
             f1="hotelId", d1=r(1, 50), f2="status", d2=c(BOOKING), q=(25, "confirmed"),
             title="Booking", extra={"nights": r(1, 14), "guests": r(1, 5)}),
    6:  dict(name="Склад", collection="stock",
             f1="warehouseId", d1=r(1, 10), f2="categoryId", d2=r(1, 40), q=(5, 20),
             title="Item", extra={"qty": r(0, 1000), "supplierId": r(1, 80)}),
    7:  dict(name="Медицинские записи (синтетические)", collection="visits",
             f1="clinicId", d1=r(1, 30), f2="visitType", d2=c(VISITS), q=(15, "checkup"),
             title="Visit", extra={"doctorId": r(1, 300), "durationMin": r(10, 90)}),
    8:  dict(name="Кафе", collection="menu_orders",
             f1="restaurantId", d1=r(1, 40), f2="categoryId", d2=r(1, 12), q=(20, 6),
             title="Dish", extra={"price": r(800, 9000), "tableNo": r(1, 30)}),
    9:  dict(name="Доставка", collection="deliveries",
             f1="courierId", d1=r(1, 200), f2="status", d2=c(DELIVERY), q=(100, "delivered"),
             title="Parcel", extra={"weightG": r(100, 20000), "zoneId": r(1, 15)}),
    10: dict(name="Сервис заявок", collection="tickets",
             f1="departmentId", d1=r(1, 20), f2="priority", d2=c(PRIORITY), q=(10, "high"),
             title="Ticket", extra={"assigneeId": r(1, 100), "slaHours": r(1, 72)}),
    11: dict(name="События устройств", collection="device_events",
             f1="deviceId", d1=r(1, 300), f2="eventType", d2=c(EVENTS), q=(150, "alarm"),
             title="Event", extra={"value": r(0, 1000), "firmware": r(1, 9)}),
    12: dict(name="Успеваемость", collection="grades",
             f1="groupId", d1=r(1, 60), f2="semester", d2=r(1, 8), q=(30, 5),
             title="Grade", extra={"studentId": r(1, 1500), "score": r(0, 100)}),
    13: dict(name="Публикации", collection="publications",
             f1="authorId", d1=r(1, 400), f2="year", d2=r(2005, 2025), q=(200, 2020),
             title="Paper", extra={"citations": r(0, 500), "journalId": r(1, 90)}),
    14: dict(name="Транспорт", collection="trips",
             f1="routeId", d1=r(1, 80), f2="weekday", d2=r(1, 7), q=(40, 3),
             title="Trip", extra={"busId": r(1, 250), "passengers": r(0, 120)}),
    15: dict(name="Платформа курсов", collection="online_courses",
             f1="teacherId", d1=r(1, 150), f2="level", d2=c(LEVELS), q=(75, "advanced"),
             title="Course", extra={"lessons": r(5, 60), "rating": r(1, 5)}),
    16: dict(name="Магазин одежды", collection="clothes",
             f1="brandId", d1=r(1, 60), f2="season", d2=c(SEASONS), q=(30, "winter"),
             title="Item", extra={"size": r(40, 56), "price": r(3000, 80000)}),
    17: dict(name="Отели", collection="hotels",
             f1="cityId", d1=r(1, 40), f2="stars", d2=r(1, 5), q=(20, 4),
             title="Hotel", extra={"rooms": r(10, 400), "priceKzt": r(8000, 150000)}),
    18: dict(name="Фитнес", collection="memberships",
             f1="clubId", d1=r(1, 25), f2="membershipType", d2=c(MEMBERSHIP), q=(12, "premium"),
             title="Member", extra={"months": r(1, 24), "visits": r(0, 300)}),
    19: dict(name="Билеты", collection="tickets_sales",
             f1="eventId", d1=r(1, 100), f2="zone", d2=c(ZONES), q=(50, "parter"),
             title="Ticket", extra={"row": r(1, 40), "price": r(2000, 60000)}),
    20: dict(name="Система проектов", collection="tasks",
             f1="teamId", d1=r(1, 30), f2="stage", d2=c(STAGES), q=(15, "dev"),
             title="Task", extra={"estimateH": r(1, 40), "ownerId": r(1, 200)}),
}


def get_variant(number: int) -> dict:
    if number not in VARIANTS:
        raise SystemExit(f"Нет варианта {number}; допустимо 1..20")
    v = dict(VARIANTS[number])
    v["number"] = number
    v["index_spec"] = [(v["f1"], 1), (v["f2"], 1)]
    v["index_name"] = f"{v['f1']}_1_{v['f2']}_1"
    v["query"] = {v["f1"]: v["q"][0], v["f2"]: v["q"][1]}
    return v


def _value(rng: random.Random, domain: dict):
    if domain["type"] == "int":
        return rng.randint(domain["min"], domain["max"])
    return rng.choice(domain["values"])


def generate_documents(v: dict, n: int, seed: int):
    """Детерминированная генерация: одинаковый seed -> одинаковые документы.

    Порядок вызовов random совпадает с примером из методички
    (f1, f2, затем дополнительные поля).
    """
    rng = random.Random(seed)
    docs = []
    for i in range(n):
        d = {"_id": i + 1,
             v["f1"]: _value(rng, v["d1"]),
             v["f2"]: _value(rng, v["d2"]),
             "title": f"{v['title']} {i}"}
        for field, dom in v["extra"].items():
            d[field] = _value(rng, dom)
        docs.append(d)
    return docs
