"""Два бэкенда хранилища с одинаковым интерфейсом.

* MongoBackend  — основной: реальный MongoDB через pymongo.
* MemoryBackend — резервный: локальное Python-хранилище, допускаемое
  методичкой (раздел 2), если MongoDB недоступна. Он моделирует
  COLLSCAN (полный перебор) и IXSCAN (составной B-tree-подобный индекс
  на отсортированном списке ключей) и возвращает explain-подобную
  статистику. Результаты этого режима помечаются как модельные.
"""
import bisect
import platform
import sys
import threading
from time import perf_counter

import config


class MongoBackend:
    kind = "mongo"

    def __init__(self, v):
        try:
            from pymongo import MongoClient
            import pymongo
        except ImportError as exc:  # pragma: no cover
            raise SystemExit("Не установлен pymongo: pip install -r requirements.txt") from exc
        self.v = v
        self.pymongo_version = pymongo.version
        self.client = MongoClient(config.MONGO_URI, serverSelectionTimeoutMS=3000,
                                  maxPoolSize=max(config.CLIENTS) + 4)
        self.db = self.client[config.DB_NAME]
        self.coll = self.db[v["collection"]]
        self.client.admin.command("ping")

    # --- данные ---
    def load(self, docs):
        self.coll.drop()  # только учебная коллекция этой работы!
        self.coll.insert_many(docs)

    def count(self):
        return self.coll.count_documents({})

    # --- индекс ---
    def has_index(self):
        return self.v["index_name"] in self.coll.index_information()

    def drop_index(self):
        if self.has_index():
            self.coll.drop_index(self.v["index_name"])

    def create_index(self):
        self.coll.create_index(self.v["index_spec"], name=self.v["index_name"])

    def index_sizes(self):
        try:
            stats = next(self.coll.aggregate([{"$collStats": {"storageStats": {}}}]))
            ss = stats["storageStats"]
        except Exception:
            ss = self.db.command("collStats", self.v["collection"])
        return {"indexSizes": dict(ss.get("indexSizes", {})),
                "totalIndexSize": ss.get("totalIndexSize"),
                "storageSize": ss.get("storageSize")}

    # --- запросы ---
    def find_ap01(self, query, limit):
        return list(self.coll.find(query).limit(limit))

    def explain(self, ap, query):
        cmd = {"find": self.v["collection"], "filter": query}
        if ap == "AP-03":
            cmd = {"count": self.v["collection"], "query": query}
        elif ap == "AP-01":
            cmd["limit"] = config.LIMIT
        res = self.db.command("explain", cmd, verbosity="executionStats")
        es = res["executionStats"]
        return {"winningPlan": _plan_stages(res["queryPlanner"]["winningPlan"]),
                "nReturned": es.get("nReturned"),
                "totalDocsExamined": es.get("totalDocsExamined"),
                "totalKeysExamined": es.get("totalKeysExamined"),
                "executionTimeMillis": es.get("executionTimeMillis"),
                "raw": _jsonable(res["queryPlanner"]["winningPlan"])}

    # --- запись (для оценки стоимости записи) ---
    def write_test(self, docs, with_index):
        coll = self.db[self.v["collection"] + "_write_test"]
        coll.drop()
        if with_index:
            coll.create_index(self.v["index_spec"], name=self.v["index_name"])
        lat = []
        for d in docs:
            t = perf_counter()
            coll.insert_one(dict(d))
            lat.append((perf_counter() - t) * 1000)
        coll.drop()
        return lat

    def environment(self):
        info = self.client.server_info()
        return {"backend": "MongoDB", "db_version": info.get("version"),
                "driver": f"pymongo {self.pymongo_version}",
                "storage_engine": self.db.command("serverStatus").get("storageEngine", {}).get("name")}


def _plan_stages(plan):
    """Сворачивает дерево winningPlan в строку вида LIMIT <- FETCH <- IXSCAN."""
    # MongoDB 7+/8 с SBE: queryPlan внутри winningPlan
    if "queryPlan" in plan:
        plan = plan["queryPlan"]
    stages = []
    node = plan
    while node:
        name = node.get("stage", "?")
        if name == "IXSCAN":
            name += f" {{{node.get('indexName', '')}}}"
        stages.append(name)
        node = node.get("inputStage") or (node.get("inputStages") or [None])[0]
    return " → ".join(stages)


def _jsonable(obj):
    import json
    return json.loads(json.dumps(obj, default=str))


class MemoryBackend:
    """Локальная модель: список документов + первичный ключ + составной индекс."""
    kind = "memory"

    def __init__(self, v):
        self.v = v
        self.docs = []
        self.by_id = {}
        self.index = None  # отсортированный список (k1, k2, pos)
        self.lock = threading.Lock()

    def load(self, docs):
        self.docs = [dict(d) for d in docs]
        self.by_id = {d["_id"]: i for i, d in enumerate(self.docs)}
        self.index = None

    def count(self):
        return len(self.docs)

    def has_index(self):
        return self.index is not None

    def drop_index(self):
        self.index = None

    def create_index(self):
        f1, f2 = self.v["f1"], self.v["f2"]
        self.index = sorted((_k(d[f1]), _k(d[f2]), i) for i, d in enumerate(self.docs))

    def index_sizes(self):
        def size_of(lst):
            return sys.getsizeof(lst) + sum(sys.getsizeof(t) for t in lst)
        sizes = {"_id_": sys.getsizeof(self.by_id)}
        if self.index is not None:
            sizes[self.v["index_name"]] = size_of(self.index)
        return {"indexSizes": sizes, "totalIndexSize": sum(sizes.values()),
                "storageSize": sum(sys.getsizeof(d) for d in self.docs)}

    # --- исполнение запросов с подсчётом статистики как в explain ---
    def _exec(self, query, limit=None, count_only=False):
        f1, f2 = self.v["f1"], self.v["f2"]
        docs_examined = keys_examined = 0
        out = []
        if set(query) == {"_id"}:
            keys_examined = 1
            pos = self.by_id.get(query["_id"])
            if pos is not None:
                docs_examined = 1
                out.append(dict(self.docs[pos]))
            return out, "EXPRESS_IXSCAN {_id_} (модель IDHACK)", docs_examined, keys_examined
        if self.index is not None and f1 in query:
            k1 = _k(query[f1])
            if f2 in query:
                k2 = _k(query[f2])
                lo = bisect.bisect_left(self.index, (k1, k2, -1))
                hi = bisect.bisect_right(self.index, (k1, k2, float("inf")))
            else:
                lo = bisect.bisect_left(self.index, (k1,))
                hi = bisect.bisect_left(self.index, (k1 + "￿",))
            for k in range(lo, hi):
                keys_examined += 1
                if count_only:
                    out.append(1)
                    continue
                docs_examined += 1
                out.append(dict(self.docs[self.index[k][2]]))
                if limit and len(out) >= limit:
                    break
            if count_only:
                plan = f"COUNT → COUNT_SCAN {{{self.v['index_name']}}}"
            else:
                plan = f"LIMIT → FETCH → IXSCAN {{{self.v['index_name']}}}"
            return out, plan, docs_examined, keys_examined
        # COLLSCAN
        for d in self.docs:
            docs_examined += 1
            if all(d.get(k) == val for k, val in query.items()):
                out.append(1 if count_only else dict(d))
                if limit and not count_only and len(out) >= limit:
                    break
        plan = "COUNT → COLLSCAN" if count_only else "LIMIT → COLLSCAN"
        return out, plan, docs_examined, keys_examined

    def find_ap01(self, query, limit):
        return self._exec(query, limit)[0]

    def explain(self, ap, query):
        t = perf_counter()
        out, plan, de, ke = self._exec(query, config.LIMIT if ap == "AP-01" else None,
                                       count_only=(ap == "AP-03"))
        ms = (perf_counter() - t) * 1000
        return {"winningPlan": plan, "nReturned": len(out) if ap != "AP-03" else 1,
                "count": len(out) if ap == "AP-03" else None,
                "totalDocsExamined": de, "totalKeysExamined": ke,
                "executionTimeMillis": round(ms, 3), "raw": {"model": plan}}

    def write_test(self, docs, with_index):
        f1, f2 = self.v["f1"], self.v["f2"]
        store, index, lat = [], [] if with_index else None, []
        for d in docs:
            t = perf_counter()
            with self.lock:
                store.append(dict(d))
                if index is not None:
                    bisect.insort(index, (_k(d[f1]), _k(d[f2]), len(store) - 1))
            lat.append((perf_counter() - t) * 1000)
        return lat

    def environment(self):
        return {"backend": "Локальное Python-хранилище (модель, MongoDB недоступна)",
                "db_version": "n/a (модель)", "driver": "—", "storage_engine": "in-memory list + sorted index"}


def _k(value):
    """Ключ индекса: приводим к строке фиксированной ширины, чтобы
    смешанные типы сортировались корректно и работал префиксный поиск."""
    if isinstance(value, int):
        return f"i{value:012d}"
    return f"s{value}"


def get_backend(v):
    if config.BACKEND == "memory":
        return MemoryBackend(v)
    return MongoBackend(v)


def host_info():
    import os
    return {"python": platform.python_version(), "os": f"{platform.system()} {platform.release()}",
            "machine": platform.machine(), "cpu_count": os.cpu_count(),
            "processor": platform.processor() or platform.machine()}
