"""Шаг 1. Генерация воспроизводимого синтетического набора данных.

Запуск:  python seed.py            (вариант и seed берутся из .env)
         python seed.py --variant 1 --seed 42 --docs 5000

Удаляет и пересоздаёт ТОЛЬКО учебную коллекцию этой работы.
Печатает число документов и SHA-256 набора: одинаковый seed даёт
одинаковую контрольную сумму — это доказательство воспроизводимости.
"""
import argparse
import hashlib
import json
from collections import Counter

import config
from storage import get_backend
from variants import get_variant, generate_documents


def dataset_fingerprint(docs):
    payload = json.dumps(docs, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def describe(v, docs):
    f1, f2 = v["f1"], v["f2"]
    q1, q2 = v["q"]
    pairs = Counter((d[f1], d[f2]) for d in docs)
    return {"variant": v["number"], "variant_name": v["name"], "collection": v["collection"],
            "seed": config.SEED, "n_docs": len(docs), "sha256": dataset_fingerprint(docs),
            "distinct_f1": len({d[f1] for d in docs}), "distinct_f2": len({d[f2] for d in docs}),
            "distinct_pairs": len(pairs),
            "matches_ap01": pairs[(q1, q2)],
            "matches_ap03": sum(1 for d in docs if d[f1] == q1),
            "avg_docs_per_pair": round(len(docs) / max(1, len(pairs)), 1),
            "sample": docs[:3]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", type=int, default=config.VARIANT)
    ap.add_argument("--seed", type=int, default=config.SEED)
    ap.add_argument("--docs", type=int, default=config.N_DOCS)
    args = ap.parse_args()
    config.VARIANT, config.SEED, config.N_DOCS = args.variant, args.seed, args.docs

    v = get_variant(args.variant)
    docs = generate_documents(v, args.docs, args.seed)
    info = describe(v, docs)

    backend = get_backend(v)
    backend.load(docs)
    info["count_in_db"] = backend.count()

    config.RESULTS_DIR.mkdir(exist_ok=True)
    (config.RESULTS_DIR / "dataset.json").write_text(
        json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Вариант {v['number']:02d}: {v['name']} -> {config.DB_NAME}.{v['collection']}")
    print(f"Документов: {info['count_in_db']} (seed={args.seed})")
    print(f"SHA-256 набора: {info['sha256']}")
    print(f"Документов под AP-01 {v['query']}: {info['matches_ap01']}")
    return backend, docs


if __name__ == "__main__":
    main()
