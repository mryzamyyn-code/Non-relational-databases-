# Лабораторная работа №12 — воспроизводимый benchmark NoSQL (MongoDB)

Дисциплина: «Проектирование и применение NoSQL-технологий».
Вариант 01 — «Каталог курсов»: коллекция `courses`, фильтр `departmentId + semester`.

Эксперимент сравнивает чтение AP-01 `find({departmentId: 10, semester: 5}).limit(100)`
**без составного индекса** и **с индексом** `{departmentId: 1, semester: 1}` при 1, 4 и 8
параллельных клиентах (closed-loop), по 3 повтора с отдельным прогревом. Измеряются
P50/P95/P99, RPS, ошибки и длительность. Дополнительно фиксируются планы `explain("executionStats")`,
стоимость записи и размер индекса.

Полный протокол: **[report.pdf](report.pdf)**.

## Структура репозитория

| Файл / папка | Назначение |
|---|---|
| `seed.py` | генерация 5000 синтетических документов (seed=42), загрузка, SHA-256 набора |
| `benchmark.py` | весь эксперимент по разделу 8: explain до/после, 2 режима × 3 уровня нагрузки × 3 повтора, запись, размер индекса |
| `analyze.py` | медианы трёх повторов, процентили по объединённым сырым данным, графики |
| `make_report.py` | автоматическая сборка `report.pdf` из результатов |
| `run_all.py` | все шаги одной командой |
| `variants.py` | описание 20 вариантов из методички (по умолчанию вариант 01) |
| `storage.py` | бэкенды: MongoDB (pymongo) и резервная локальная модель |
| `config.py` | чтение параметров из `.env` |
| `results.csv` | сырые результаты каждого прогона |
| `results/` | `raw_latencies.csv` (все задержки), `summary.csv`, `explain.json`, `environment.json`, `dataset.json`, `write_cost.json`, `index_sizes.json` |
| `charts/` | `p95_by_clients.png`, `throughput_by_clients.png` |
| `.env.example` | образец настроек без паролей |

## Как воспроизвести

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # Windows: copy .env.example .env
# в .env: ФИО для титульного листа; при необходимости MONGO_URI
python run_all.py             # = seed.py -> benchmark.py -> analyze.py -> make_report.py
```

Нужен локальный MongoDB на `mongodb://localhost:27017` (например, MongoDB Community Server или
`docker run -d -p 27017:27017 --name mongo mongo:8`). Скрипты удаляют и пересоздают **только**
учебную коллекцию `nosql_lab12.courses` и **только** индекс `departmentId_1_semester_1`.

Проверка плана в mongosh:

```js
use nosql_lab12
db.courses.find({departmentId: 10, semester: 5}).explain("executionStats")
db.courses.createIndex({departmentId: 1, semester: 1})
db.courses.find({departmentId: 10, semester: 5}).explain("executionStats")
```

Если MongoDB недоступна, методичка допускает моделирование: `BACKEND=memory` в `.env` запускает
тот же сценарий на локальном Python-хранилище (COLLSCAN/IXSCAN-модель). Отчёт в этом случае сам
помечает результаты как модельные и добавляет ограничение эксперимента.

Другой вариант: `VARIANT=N` в `.env` (1–20) — данные, фильтр и индекс подставятся автоматически.

## Воспроизводимость

* фиксированный `SEED=42` и SHA-256 всего набора данных (`results/dataset.json`);
* одинаковые набор данных, запрос и число запросов в обоих режимах; меняется только индекс;
* версии ПО и параметры стенда сохраняются в `results/environment.json`;
* сырые задержки всех прогонов в CSV; процентили по объединённым данным считаются из них, а не
  усреднением P95 отдельных запусков.

## Результаты

![P95](charts/p95_by_clients.png)
![Throughput](charts/throughput_by_clients.png)

Таблицы, explain, расчёт улучшения P95, стоимость записи, интерпретация и выводы — в `report.pdf`.
