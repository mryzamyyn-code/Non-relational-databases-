"""Шаг 3. Анализ: медианы трёх повторов, объединённые процентили, графики.

Запуск:  python analyze.py
Читает results.csv и results/raw_latencies.csv, пишет results/summary.csv,
results/analysis.json и графики в charts/.

Важно (раздел 10): P95 отдельных запусков НЕ усредняются. Для каждой
конфигурации приводится (а) медиана трёх запусков и (б) процентиль по
объединённым сырым задержкам всех трёх повторов.
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

import config
from benchmark import percentile

COLORS = {"baseline": "#f47230", "indexed": "#257de0"}   # проверенная пара палитры (слоты 2 и 1)
MARKERS = {"baseline": "s", "indexed": "o"}
LABELS = {"baseline": "Без индекса (COLLSCAN)", "indexed": "С индексом (IXSCAN)"}
TEXT, GRID = "#191919", "#e6e6e6"


def build_summary(runs, raw):
    out = []
    for (mode, clients), g in runs.groupby(["mode", "clients"], sort=False):
        lat = raw[(raw["mode"] == mode) & (raw["clients"] == clients)]["latency_ms"].tolist()
        attempts, errors = int(g["requests"].sum()), int(g["errors"].sum())
        out.append({"mode": mode, "clients": clients,
                    "rps_median": round(g["rps"].median(), 1),
                    "p50_median": round(g["p50_ms"].median(), 4),
                    "p95_median": round(g["p95_ms"].median(), 4),
                    "p99_median": round(g["p99_ms"].median(), 4),
                    "p50_pooled": round(percentile(lat, 50), 4),
                    "p95_pooled": round(percentile(lat, 95), 4),
                    "p99_pooled": round(percentile(lat, 99), 4),
                    "attempts": attempts, "errors": errors,
                    "error_rate_pct": round(errors / attempts * 100, 3),
                    "duration_median_s": round(g["duration_s"].median(), 4)})
    return pd.DataFrame(out)


def improvements(summary):
    res = []
    for clients in sorted(summary["clients"].unique()):
        b = summary[(summary["mode"] == "baseline") & (summary["clients"] == clients)].iloc[0]
        i = summary[(summary["mode"] == "indexed") & (summary["clients"] == clients)].iloc[0]
        res.append({"clients": int(clients),
                    "p95_before": b["p95_median"], "p95_after": i["p95_median"],
                    "p95_improvement_pct": round((b["p95_median"] - i["p95_median"]) / b["p95_median"] * 100, 2),
                    "p95_pooled_before": b["p95_pooled"], "p95_pooled_after": i["p95_pooled"],
                    "p95_pooled_improvement_pct": round((b["p95_pooled"] - i["p95_pooled"]) / b["p95_pooled"] * 100, 2),
                    "rps_before": b["rps_median"], "rps_after": i["rps_median"],
                    "rps_gain_x": round(i["rps_median"] / b["rps_median"], 2)})
    return res


def _style(ax, title, ylabel, log=False):
    ax.set_title(title, loc="left", fontsize=12, color=TEXT, pad=10)
    ax.set_xlabel("Число параллельных клиентов", color=TEXT)
    ax.set_ylabel(ylabel, color=TEXT)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#999999")
    ax.tick_params(colors="#666666")
    ax.set_xticks(config.CLIENTS)
    if not log:
        ax.set_ylim(bottom=0)


def chart(runs, summary, metric_run, metric_sum, title, ylabel, path, log=False):
    fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=150)
    for mode in ("baseline", "indexed"):
        r = runs[runs["mode"] == mode]
        s = summary[summary["mode"] == mode]
        ax.scatter(r["clients"], r[metric_run], s=22, color=COLORS[mode], alpha=0.35,
                   marker=MARKERS[mode], linewidths=0, zorder=2)
        ax.plot(s["clients"], s[metric_sum], color=COLORS[mode], linewidth=2, marker=MARKERS[mode],
                markersize=7, markeredgecolor="white", markeredgewidth=1.5, label=LABELS[mode], zorder=3)
        last = s.iloc[-1]
        ax.annotate(f"{last[metric_sum]:.2f}" if last[metric_sum] < 100 else f"{last[metric_sum]:.0f}",
                    (last["clients"], last[metric_sum]), xytext=(8, 0), textcoords="offset points",
                    va="center", fontsize=9, color=TEXT)
    if log:
        ax.set_yscale("log")
        ylabel += " (лог. шкала)"
    _style(ax, title, ylabel, log)
    ax.set_xlim(min(config.CLIENTS) - 0.5, max(config.CLIENTS) + 1.2)
    ax.legend(frameon=False, loc="best", fontsize=9)
    fig.text(0.01, 0.01, "Линия — медиана трёх повторов; бледные точки — отдельные повторы",
             fontsize=8, color="#666666")
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(path)
    plt.close(fig)


def main():
    runs = pd.read_csv(config.RESULTS_CSV)
    raw = pd.read_csv(config.RESULTS_DIR / "raw_latencies.csv")
    summary = build_summary(runs, raw)
    summary.to_csv(config.RESULTS_DIR / "summary.csv", index=False)
    imp = improvements(summary)
    (config.RESULTS_DIR / "analysis.json").write_text(json.dumps(imp, ensure_ascii=False, indent=2),
                                                     encoding="utf-8")
    config.CHARTS_DIR.mkdir(exist_ok=True)
    chart(runs, summary, "p95_ms", "p95_median", "P95 задержки AP-01 по числу клиентов",
          "P95, мс", config.CHARTS_DIR / "p95_by_clients.png", log=True)
    chart(runs, summary, "rps", "rps_median", "Пропускная способность AP-01 по числу клиентов",
          "Успешных запросов/с (RPS)", config.CHARTS_DIR / "throughput_by_clients.png", log=True)
    print(summary.to_string(index=False))
    print(json.dumps(imp, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
