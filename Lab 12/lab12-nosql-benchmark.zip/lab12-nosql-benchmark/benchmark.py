"""Шаг 2. Воспроизводимый closed-loop benchmark AP-01: без индекса и с индексом.

Запуск:  python seed.py && python benchmark.py

Порядок (раздел 8 методички):
 1) проверка числа документов и контрольной суммы набора;
 2) удаление только составного индекса этой работы, baseline explain;
 3) для 1/4/8 клиентов — по 3 повтора, перед каждым прогоном warm-up;
 4) создание индекса {f1: 1, f2: 1}, повтор explain и всего эксперимента
    с тем же seed, набором данных и числом запросов;
 5) сохранение сырых данных в CSV (results.csv, results/raw_latencies.csv).
Дополнительно измеряется стоимость записи и размер индексов.
"""
import argparse
import csv
import json
import math
import statistics
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from time import perf_counter

import config
from seed import dataset_fingerprint
from storage import get_backend, host_info
from variants import get_variant, generate_documents

MODES = {"baseline": "Без индекса", "indexed": "С индексом"}


def percentile(values, p):
    """Линейная интерполяция между соседними рангами (как в методичке)."""
    v = sorted(values)
    if not v:
        return float("nan")
    idx = (len(v) - 1) * p / 100
    lo, hi = math.floor(idx), math.ceil(idx)
    return v[lo] + (v[hi] - v[lo]) * (idx - lo)


class Runner:
    def __init__(self, backend, query, limit):
        self.backend, self.query, self.limit = backend, query, limit

    def one(self):
        start = perf_counter()
        try:
            self.backend.find_ap01(self.query, self.limit)
            return (perf_counter() - start) * 1000, True
        except Exception:
            return (perf_counter() - start) * 1000, False

    def run(self, workers, n, warmup):
        for _ in range(warmup):          # warm-up отдельно, в измерения не входит
            self.one()
        t0 = perf_counter()
        with ThreadPoolExecutor(max_workers=workers) as pool:
            results = list(pool.map(lambda _: self.one(), range(n)))
        seconds = perf_counter() - t0
        lat = [ms for ms, ok in results if ok]
        success = len(lat)
        return {"workers": workers, "requests": n, "success": success, "errors": n - success,
                "error_rate_pct": round((n - success) / n * 100, 3),
                "duration_s": round(seconds, 4), "rps": round(success / seconds, 1),
                "p50_ms": round(percentile(lat, 50), 4), "p95_ms": round(percentile(lat, 95), 4),
                "p99_ms": round(percentile(lat, 99), 4),
                "mean_ms": round(statistics.mean(lat), 4) if lat else float("nan"),
                "max_ms": round(max(lat), 4) if lat else float("nan")}, lat


def explain_all(backend, v):
    queries = {"AP-01": v["query"], "AP-02": {"_id": config.N_DOCS // 2},
               "AP-03": {v["f1"]: v["q"][0]}}
    return {ap: dict(query=_q(q), **backend.explain(ap, q)) for ap, q in queries.items()}


def _q(q):
    return json.loads(json.dumps(q))


def write_cost(backend, v, with_index):
    docs = generate_documents(v, config.WRITE_TEST_DOCS, config.SEED + 1)
    for d in docs:
        d["_id"] += 10_000_000
    lat = backend.write_test(docs, with_index)
    return {"docs": len(lat), "mean_ms": round(statistics.mean(lat), 4),
            "p50_ms": round(percentile(lat, 50), 4), "p95_ms": round(percentile(lat, 95), 4),
            "total_s": round(sum(lat) / 1000, 4)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", type=int, default=config.VARIANT)
    args = ap.parse_args()
    config.VARIANT = args.variant
    v = get_variant(args.variant)
    backend = get_backend(v)
    expected = generate_documents(v, config.N_DOCS, config.SEED)

    # 1) проверка набора данных
    if backend.kind == "memory":
        backend.load(expected)  # модельное хранилище живёт в памяти процесса
    n = backend.count()
    if n != config.N_DOCS:
        raise SystemExit(f"В коллекции {n} документов, ожидалось {config.N_DOCS}. Запустите python seed.py")

    env = {"started_at": datetime.now().isoformat(timespec="seconds"), "variant": v["number"],
           "variant_name": v["name"], "collection": f"{config.DB_NAME}.{v['collection']}",
           "query_ap01": v["query"], "index": v["index_name"], "n_docs": n, "seed": config.SEED,
           "dataset_sha256": dataset_fingerprint(expected), "requests_per_run": config.REQUESTS,
           "warmup_per_run": config.WARMUP, "repeats": config.REPEATS, "clients": config.CLIENTS,
           "limit": config.LIMIT, "slo_p95_ms": config.SLO_P95_MS, "slo_error_rate_pct": config.SLO_ERROR_RATE,
           **backend.environment(), **host_info()}
    print(json.dumps(env, ensure_ascii=False, indent=1))

    runner = Runner(backend, v["query"], config.LIMIT)
    rows, raw, explain, sizes, writes = [], [], {}, {}, {}

    for mode in ("baseline", "indexed"):
        if mode == "baseline":
            backend.drop_index()               # 2) удаляем только индекс этой работы
        else:
            backend.create_index()             # 4) создаём составной индекс
        explain[mode] = explain_all(backend, v)
        sizes[mode] = backend.index_sizes()
        print(f"\n=== {MODES[mode]}: {explain[mode]['AP-01']['winningPlan']} | "
              f"docsExamined={explain[mode]['AP-01']['totalDocsExamined']} "
              f"keysExamined={explain[mode]['AP-01']['totalKeysExamined']}")
        for workers in config.CLIENTS:         # 3) 1/4/8 клиентов × 3 повтора
            for repeat in range(1, config.REPEATS + 1):
                res, lat = runner.run(workers, config.REQUESTS, config.WARMUP)
                row = {"mode": mode, "mode_ru": MODES[mode], "clients": workers, "repeat": repeat, **res}
                row.pop("workers")
                rows.append(row)
                raw.extend((mode, workers, repeat, i, round(ms, 5)) for i, ms in enumerate(lat))
                print(f"{MODES[mode]:12s} clients={workers} repeat={repeat} rps={res['rps']:>8} "
                      f"p50={res['p50_ms']:.3f} p95={res['p95_ms']:.3f} p99={res['p99_ms']:.3f} "
                      f"errors={res['errors']}")
        writes[mode] = write_cost(backend, v, with_index=(mode == "indexed"))
        print(f"Стоимость записи ({MODES[mode]}): {writes[mode]}")

    # 5) сохраняем сырые результаты
    config.RESULTS_DIR.mkdir(exist_ok=True)
    with open(config.RESULTS_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    with open(config.RESULTS_DIR / "raw_latencies.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["mode", "clients", "repeat", "request_no", "latency_ms"])
        w.writerows(raw)
    env["finished_at"] = datetime.now().isoformat(timespec="seconds")
    dump = lambda name, obj: (config.RESULTS_DIR / name).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    dump("environment.json", env)
    dump("explain.json", explain)
    dump("index_sizes.json", sizes)
    dump("write_cost.json", writes)
    print(f"\nГотово: {config.RESULTS_CSV}, {config.RESULTS_DIR}/")


if __name__ == "__main__":
    main()
