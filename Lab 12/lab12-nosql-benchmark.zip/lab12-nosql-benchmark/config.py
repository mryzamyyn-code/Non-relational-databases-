"""Общая конфигурация лабораторной работы №12.

Параметры читаются из файла .env (если он есть) и переменных окружения.
Файл .env не коммитится в репозиторий — образец лежит в .env.example.
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _load_dotenv(path: Path) -> None:
    """Минимальный парсер .env без внешних зависимостей."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(ROOT / ".env")


def _int_list(value: str):
    return [int(x) for x in value.replace(" ", "").split(",") if x]


# --- Подключение и стенд ---
BACKEND = os.getenv("BACKEND", "mongo").lower()          # mongo | memory
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "nosql_lab12")
COLLECTION = os.getenv("COLLECTION", "courses")

# --- Параметры эксперимента ---
VARIANT = int(os.getenv("VARIANT", "1"))
SEED = int(os.getenv("SEED", "42"))
N_DOCS = int(os.getenv("N_DOCS", "5000"))
REQUESTS = int(os.getenv("REQUESTS", "1000"))     # запросов в одном прогоне
WARMUP = int(os.getenv("WARMUP", "100"))          # запросов прогрева перед каждым прогоном
REPEATS = int(os.getenv("REPEATS", "3"))
CLIENTS = _int_list(os.getenv("CLIENTS", "1,4,8"))
LIMIT = int(os.getenv("LIMIT", "100"))
WRITE_TEST_DOCS = int(os.getenv("WRITE_TEST_DOCS", "1000"))

# --- SLO (целевые уровни сервиса для AP-01) ---
SLO_P95_MS = float(os.getenv("SLO_P95_MS", "20"))
SLO_ERROR_RATE = float(os.getenv("SLO_ERROR_RATE", "1"))  # %

# --- Данные для титульного листа ---
UNIVERSITY = os.getenv("UNIVERSITY", "Алматинский технологический университет")
STUDENT_NAME = os.getenv("STUDENT_NAME", "________________")
GROUP = os.getenv("GROUP", "ИС 24-21")
TEACHER_NAME = os.getenv("TEACHER_NAME", "________________")
CITY_YEAR = os.getenv("CITY_YEAR", "Алматы 2026")

INDEX_NAME_SUFFIX = "_lab12"  # используется только для пометки в отчёте

# Пути к результатам
RESULTS_CSV = ROOT / "results.csv"
RESULTS_DIR = ROOT / "results"
CHARTS_DIR = ROOT / "charts"
REPORT_PDF = ROOT / "report.pdf"
