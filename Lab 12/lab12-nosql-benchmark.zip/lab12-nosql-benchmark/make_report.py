"""Шаг 4. Автоматическая сборка отчёта report.pdf из результатов эксперимента.

Запуск:  python make_report.py
Все числа в отчёте берутся из results.csv и файлов results/*.json,
поэтому после повторного запуска эксперимента на своём стенде отчёт
пересобирается с вашими реальными измерениями.
Данные титульного листа (ФИО, преподаватель) задаются в .env.
"""
import inspect
import json
import os
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

import benchmark
import config
import variants

# ---------- шрифты: Times New Roman, если есть в системе, иначе метрический аналог ----------
SERIF = [("C:/Windows/Fonts/times.ttf", "C:/Windows/Fonts/timesbd.ttf", "C:/Windows/Fonts/timesi.ttf"),
         ("/Library/Fonts/Times New Roman.ttf", "/Library/Fonts/Times New Roman Bold.ttf",
          "/Library/Fonts/Times New Roman Italic.ttf"),
         ("/System/Library/Fonts/Supplemental/Times New Roman.ttf",
          "/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf",
          "/System/Library/Fonts/Supplemental/Times New Roman Italic.ttf"),
         ("/usr/share/fonts/truetype/msttcorefonts/Times_New_Roman.ttf",
          "/usr/share/fonts/truetype/msttcorefonts/Times_New_Roman_Bold.ttf",
          "/usr/share/fonts/truetype/msttcorefonts/Times_New_Roman_Italic.ttf"),
         ("/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
          "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
          "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf"),
         ("/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
          "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
          "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf")]
MONO = ["C:/Windows/Fonts/consola.ttf", "C:/Windows/Fonts/cour.ttf",
        "/System/Library/Fonts/Supplemental/Courier New.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf"]


def register_fonts():
    for reg, bold, it in SERIF:
        if all(os.path.exists(p) for p in (reg, bold, it)):
            pdfmetrics.registerFont(TTFont("Serif", reg))
            pdfmetrics.registerFont(TTFont("Serif-Bold", bold))
            pdfmetrics.registerFont(TTFont("Serif-Italic", it))
            pdfmetrics.registerFontFamily("Serif", normal="Serif", bold="Serif-Bold", italic="Serif-Italic",
                                          boldItalic="Serif-Bold")
            break
    else:
        raise SystemExit("Не найден шрифт с кириллицей (Times New Roman / Liberation Serif)")
    for m in MONO:
        if os.path.exists(m):
            pdfmetrics.registerFont(TTFont("Mono", m))
            return
    raise SystemExit("Не найден моноширинный шрифт с кириллицей")


register_fonts()
BODY = ParagraphStyle("body", fontName="Serif", fontSize=14, leading=18, alignment=TA_JUSTIFY,
                      firstLineIndent=1.25 * cm, spaceAfter=3)
NOIND = ParagraphStyle("noind", parent=BODY, firstLineIndent=0)
H1 = ParagraphStyle("h1", fontName="Serif-Bold", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6,
                    alignment=TA_LEFT, keepWithNext=1)
CENTER = ParagraphStyle("c", parent=BODY, alignment=TA_CENTER, firstLineIndent=0)
CAPTION = ParagraphStyle("cap", fontName="Serif", fontSize=12, leading=14, alignment=TA_CENTER,
                         spaceBefore=3, spaceAfter=8)
TCAP = ParagraphStyle("tcap", fontName="Serif", fontSize=12, leading=14, alignment=TA_LEFT, spaceAfter=3,
                      keepWithNext=1)
CELL = ParagraphStyle("cell", fontName="Serif", fontSize=10.5, leading=12.5)
CELLC = ParagraphStyle("cellc", parent=CELL, alignment=TA_CENTER)
CODE = ParagraphStyle("code", fontName="Mono", fontSize=8, leading=9.6)


def P(text, style=BODY):
    return Paragraph(text, style)


def load():
    R = config.RESULTS_DIR
    rd = lambda n: json.loads((R / n).read_text(encoding="utf-8"))
    return dict(runs=pd.read_csv(config.RESULTS_CSV), summary=pd.read_csv(R / "summary.csv"),
                imp=rd("analysis.json"), env=rd("environment.json"), explain=rd("explain.json"),
                sizes=rd("index_sizes.json"), writes=rd("write_cost.json"), dataset=rd("dataset.json"))


def ms(x):
    x = float(x)
    if x < 0.1:
        return f"{x:.4f}"
    if x < 10:
        return f"{x:.3f}"
    return f"{x:.2f}"


def num(x):
    return f"{float(x):,.1f}".replace(",", " ")


def size(b):
    b = float(b or 0)
    return f"{b / 1024:.1f} КБ" if b < 1024 * 1024 else f"{b / 1024 / 1024:.2f} МБ"


def table(data, widths, header_rows=1, font=10.5, zebra=True):
    rows = [[c if isinstance(c, Paragraph) else Paragraph(str(c), CELLC if j else CELL)
             for j, c in enumerate(r)] for r in data]
    t = Table(rows, colWidths=widths, repeatRows=header_rows, hAlign="CENTER")
    st = [("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#808080")),
          ("BACKGROUND", (0, 0), (-1, header_rows - 1), colors.HexColor("#e8e8e8")),
          ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
          ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3)]
    t.setStyle(TableStyle(st))
    return t


def bold_row(cells):
    return [Paragraph(f"<b>{c}</b>", CELLC) for c in cells]


def title_page(d, v):
    s = []
    s.append(P(f"{config.UNIVERSITY}", CENTER))
    s.append(Spacer(1, 5.5 * cm))
    s.append(P("<b>ОТЧЁТ</b>", CENTER))
    s.append(P("<b>по лабораторной работе №12</b>", CENTER))
    s.append(Spacer(1, 0.3 * cm))
    s.append(P("«Разработка и запуск воспроизводимого benchmark-сценария»", CENTER))
    s.append(P("по дисциплине «Проектирование и применение NoSQL-технологий»", CENTER))
    s.append(Spacer(1, 0.3 * cm))
    s.append(P(f"Вариант {v['number']:02d}. {v['name']}", CENTER))
    s.append(Spacer(1, 4 * cm))
    right = ParagraphStyle("r", parent=NOIND, alignment=TA_LEFT, leftIndent=8.5 * cm)
    s.append(P(f"Выполнил(а): студент(ка) группы {config.GROUP}<br/>{config.STUDENT_NAME}", right))
    s.append(Spacer(1, 0.4 * cm))
    s.append(P(f"Проверил(а): {config.TEACHER_NAME}", right))
    s.append(Spacer(1, 4.3 * cm))
    s.append(P(config.CITY_YEAR, CENTER))
    s.append(PageBreak())
    return s


def build():
    d = load()
    env, v = d["env"], variants.get_variant(d["env"]["variant"])
    f1, f2 = v["f1"], v["f2"]
    is_model = env["backend"] != "MongoDB"
    S = d["summary"]
    base = S[S["mode"] == "baseline"].set_index("clients")
    idx = S[S["mode"] == "indexed"].set_index("clients")
    cmin, cmax = min(env["clients"]), max(env["clients"])
    imp = {r["clients"]: r for r in d["imp"]}
    ex_b, ex_i = d["explain"]["baseline"], d["explain"]["indexed"]
    W = A4[0] - 4.5 * cm
    s = title_page(d, v)

    # 1. Цель
    s += [P("1. Цель работы", H1),
          P("Разработать воспроизводимый эксперимент производительности NoSQL-подсистемы, измерить "
            "задержку (latency), пропускную способность (throughput) и ошибки, сравнить базовую "
            f"конфигурацию (без составного индекса) и оптимизированную (с индексом {{{f1}: 1, {f2}: 1}}) "
            "и обосновать выводы. В работе отрабатываются описание workload, отделение прогрева (warm-up) "
            "от измерений, расчёт P50/P95/P99, интерпретация explain и оформление протокола.")]

    # 2. Окружение
    s += [P("2. Окружение и версии", H1),
          P("Эксперимент проводился на собственном локальном стенде на синтетических данных; нагрузка "
            "на серверы университета не подавалась. Параметры стенда зафиксированы автоматически "
            "скриптом benchmark.py (файл results/environment.json):", BODY)]
    env_rows = [["Параметр", "Значение"],
                ["СУБД / хранилище", env["backend"]],
                ["Версия СУБД", env["db_version"]],
                ["Движок хранения", env.get("storage_engine") or "—"],
                ["Драйвер", env["driver"]],
                ["Python", env["python"]],
                ["ОС, архитектура", f"{env['os']}, {env['machine']}"],
                ["Логических CPU", env["cpu_count"]],
                ["Библиотеки", "pandas, matplotlib, reportlab (см. requirements.txt)"],
                ["Время эксперимента", f"{env['started_at']} – {env.get('finished_at', '')}"]]
    s.append(table(env_rows, [5.5 * cm, W - 5.5 * cm]))
    if is_model:
        s.append(Spacer(1, 4))
        s.append(P("<b>Ограничение эксперимента.</b> На стенде, где собирался данный протокол, сервер MongoDB "
                   "был недоступен, поэтому, как допускает раздел 2 методички, использовано моделирование на "
                   "локальном Python-хранилище (BACKEND=memory). Модель воспроизводит логику планов COLLSCAN и "
                   "IXSCAN (составной индекс на отсортированном списке ключей с бинарным поиском) и считает "
                   "просмотренные документы и ключи так же, как explain. Абсолютные значения задержек модели "
                   "не равны задержкам MongoDB (нет сети, BSON-сериализации и WiredTiger); корректны "
                   "относительные выводы. Тот же код с BACKEND=mongo выполняет эксперимент на реальном MongoDB.",
                   BODY))

    # 3. Схема данных и workload
    ds = d["dataset"]
    s += [P("3. Схема данных, access patterns и workload", H1),
          P(f"Учебная ИС хранит коллекцию <b>{v['collection']}</b> (база {config.DB_NAME}). Документ содержит "
            f"поля: _id (целое), {f1}, {f2}, title" + "".join(f", {k}" for k in v["extra"]) + ". "
            f"Домены значений: {f1} ∈ [{_dom(v['d1'])}], {f2} ∈ [{_dom(v['d2'])}]"
            + "".join(f", {k} ∈ [{_dom(dm)}]" for k, dm in v["extra"].items()) + ". Пример документа:"),
          Preformatted(json.dumps(ds["sample"][0], ensure_ascii=False), CODE),
          Spacer(1, 4),
          P("Access patterns: <b>AP-01</b> — поиск курсов подразделения и семестра "
            f"<font name='Mono' size='11'>find({_js(v['query'])}).limit({env['limit']})</font> (главный сценарий теста); "
            f"<b>AP-02</b> — поиск по идентификатору <font name='Mono' size='11'>find({{_id: {env['n_docs'] // 2}}})</font>; "
            f"<b>AP-03</b> — подсчёт документов подразделения <font name='Mono' size='11'>count({{{f1}: {_jsv(v['q'][0])}}})</font>."),
          P(f"Workload: закрытый цикл (closed-loop), {cmin}/…/{cmax} параллельных клиентов "
            f"({', '.join(map(str, env['clients']))}); каждый прогон — {env['requests_per_run']} запросов AP-01 с "
            f"одинаковым фильтром, перед каждым прогоном — {env['warmup_per_run']} запросов прогрева, не входящих "
            f"в измерения; {env['repeats']} повтора на каждую точку. Ошибочные операции учитываются отдельно.")]

    # 4. Гипотеза и SLO
    s += [P("4. Гипотеза и SLO", H1),
          P(f"<b>Гипотеза.</b> Составной индекс {{{f1}: 1, {f2}: 1}} уменьшит число просмотренных документов "
            f"AP-01 (с полного перебора {env['n_docs']} документов до числа совпадений) и снизит P95 чтения при "
            f"данном распределении: {ds['distinct_pairs']} различных пар ({f1}, {f2}), в среднем "
            f"≈{ds['avg_docs_per_pair']} документа на пару, т. е. селективность фильтра около "
            f"{ds['matches_ap01'] / env['n_docs'] * 100:.1f} %."),
          P(f"<b>SLO для AP-01:</b> P95 ≤ {env['slo_p95_ms']:g} мс при {cmax} клиентах и доля ошибок ≤ "
            f"{env['slo_error_rate_pct']:g} %. Нулевая гипотеза — индекс не меняет P95 существенно "
            "(разница в пределах разброса трёх повторов).")]

    # 5. Данные и seed
    s += [P("5. Исходные данные и seed", H1),
          P(f"Данные генерирует скрипт seed.py: random.Random(seed={ds['seed']}), {ds['n_docs']} документов, порядок "
            "вызовов генератора совпадает с примером методички. Перед тестом зафиксированы версия СУБД "
            f"(раздел 2) и число документов: <b>{ds['count_in_db']}</b>. Для доказательства воспроизводимости "
            "вычисляется SHA-256 от отсортированного JSON всего набора — при том же seed хэш совпадает "
            "на любой машине; benchmark.py перед запуском проверяет число документов."),
          table([["Показатель", "Значение"],
                 ["seed / число документов", f"{ds['seed']} / {ds['n_docs']}"],
                 ["SHA-256 набора", Paragraph(f"<font name='Mono' size='8'>{ds['sha256']}</font>", CELLC)],
                 [f"Различных {f1} / {f2} / пар", f"{ds['distinct_f1']} / {ds['distinct_f2']} / {ds['distinct_pairs']}"],
                 [f"Совпадений AP-01 {_js(v['query'])}", ds["matches_ap01"]],
                 [f"Совпадений AP-03 {{{f1}: {_jsv(v['q'][0])}}}", ds["matches_ap03"]]],
                [6.5 * cm, W - 6.5 * cm])]

    # 6. Код benchmark
    code = (inspect.getsource(variants.generate_documents) + "\n" + inspect.getsource(benchmark.percentile)
            + "\n" + inspect.getsource(benchmark.Runner))
    code = "\n".join(l for l in code.splitlines() if not l.strip().startswith('"""') and "Детерминированная" not in l
                     and "Порядок вызовов" not in l and "(f1, f2, затем" not in l)
    s += [P("6. Код benchmark", H1),
          P("Полный код находится в репозитории (seed.py, benchmark.py, analyze.py). Ниже — ключевые фрагменты: "
            "детерминированная генерация данных, расчёт процентиля линейной интерполяцией и closed-loop "
            "прогон с отдельным warm-up и учётом ошибок. Основной цикл перебирает режимы baseline → indexed, "
            "для каждого — числа клиентов и повторы, и сохраняет каждую строку и все сырые задержки в CSV."),
          Preformatted(code, CODE)]

    # 7. Explain
    def ex_rows(ex):
        rows = [["AP", "winningPlan", "nReturned", "docsExamined", "keysExamined", "ms"]]
        for ap in ("AP-01", "AP-02", "AP-03"):
            e = ex[ap]
            nret = e.get("count") if e.get("count") is not None else e["nReturned"]
            rows.append([ap, Paragraph(e["winningPlan"], CELL), nret, e["totalDocsExamined"],
                         e["totalKeysExamined"], e["executionTimeMillis"]])
        return rows
    wcol = [1.4 * cm, 6.6 * cm, 2 * cm, 2.5 * cm, 2.5 * cm, W - 15 * cm]
    b01, i01 = ex_b["AP-01"], ex_i["AP-01"]
    s += [P("7. Планы выполнения (explain) до и после индекса", H1),
          P(f"Команда: <font name='Mono' size='11'>db.{v['collection']}.find({_js(v['query'])}).explain(\"executionStats\")</font>; "
            f"затем <font name='Mono' size='11'>db.{v['collection']}.createIndex({{{f1}: 1, {f2}: 1}})</font> и повтор "
            "того же explain. Перед базовым тестом удалялся только индекс этой работы "
            f"({v['index_name']}); результаты — results/explain.json."),
          P("Таблица 1 — explain(\"executionStats\") без составного индекса", TCAP), table(ex_rows(ex_b), wcol),
          Spacer(1, 6),
          P("Таблица 2 — explain(\"executionStats\") с индексом", TCAP), table(ex_rows(ex_i), wcol),
          Spacer(1, 4),
          P(f"Для AP-01 план сменился с <b>{b01['winningPlan']}</b> на <b>{i01['winningPlan']}</b>: "
            f"totalDocsExamined уменьшилось с {b01['totalDocsExamined']} до {i01['totalDocsExamined']}, "
            f"totalKeysExamined = {i01['totalKeysExamined']} (ровно число совпадений, т. е. индекс идеально "
            f"селективен: docsExamined/nReturned = {_ratio(i01)}). AP-02 использует первичный индекс _id в обоих "
            f"режимах и от нового индекса не зависит. AP-03 после создания индекса использует его префикс {f1} "
            f"(просмотрено {ex_i['AP-03']['totalKeysExamined']} ключей вместо {ex_b['AP-03']['totalDocsExamined']} "
            "документов). Вывод об ускорении по одному IXSCAN не делается — он проверяется независимыми "
            "измерениями ниже.")]

    # 8. Результаты
    runs = d["runs"]
    rows = [["Режим", "Клиенты", "Повтор", "RPS", "P50, мс", "P95, мс", "P99, мс", "Ошибки", "Длит., с"]]
    for _, r in runs.iterrows():
        rows.append([r["mode_ru"], r["clients"], r["repeat"], num(r["rps"]), ms(r["p50_ms"]), ms(r["p95_ms"]),
                     ms(r["p99_ms"]), r["errors"], f"{r['duration_s']:.3f}"])
    cw = [2.9 * cm, 1.7 * cm, 1.6 * cm, 2 * cm, 1.8 * cm, 1.8 * cm, 1.8 * cm, 1.6 * cm]
    cw.append(W - sum(cw))
    s += [P("8. Результаты измерений", H1),
          P(f"Каждая строка — отдельный прогон из {env['requests_per_run']} запросов (сырые данные: results.csv, "
            "все задержки — results/raw_latencies.csv)."),
          P("Таблица 3 — результаты всех прогонов", TCAP), table(rows, cw)]

    srows = [["Режим", "Клиенты", "RPS (мед.)", "P50 (мед.)", "P95 (мед.)", "P99 (мед.)",
              "P95 объед.", "P99 объед.", "Ошиб&shy;ки, %"]]
    for _, r in S.iterrows():
        srows.append(["Без индекса" if r["mode"] == "baseline" else "С индексом", r["clients"], num(r["rps_median"]),
                      ms(r["p50_median"]), ms(r["p95_median"]), ms(r["p99_median"]), ms(r["p95_pooled"]),
                      ms(r["p99_pooled"]), f"{r['error_rate_pct']:.2f}"])
    cw2 = [2.5 * cm, 1.7 * cm, 1.9 * cm] + [1.75 * cm] * 5
    cw2.append(W - sum(cw2))
    s += [Spacer(1, 6), P("Таблица 4 — сводка: медиана трёх прогонов и процентили по объединённым сырым данным "
                          "(все задержки, мс)", TCAP), table(srows, cw2)]

    # 9. Расчёты
    irows = [["Клиенты", "P95 до, мс", "P95 после, мс", "Улучшение P95", "Улучш. (объед.)", "RPS до", "RPS после", "Рост RPS"]]
    for c in env["clients"]:
        r = imp[c]
        irows.append([c, ms(r["p95_before"]), ms(r["p95_after"]), f"{r['p95_improvement_pct']:.2f} %",
                      f"{r['p95_pooled_improvement_pct']:.2f} %", num(r["rps_before"]), num(r["rps_after"]),
                      f"×{r['rps_gain_x']:.1f}"])
    cw3 = [1.7 * cm, 2.1 * cm, 2.3 * cm, 2.3 * cm, 2.4 * cm, 2 * cm, 2.1 * cm]
    cw3.append(W - sum(cw3))
    wb, wi = d["writes"]["baseline"], d["writes"]["indexed"]
    sz_b, sz_i = d["sizes"]["baseline"], d["sizes"]["indexed"]
    new_idx = sz_i["indexSizes"].get(v["index_name"], 0)
    w_growth = (wi["mean_ms"] - wb["mean_ms"]) / wb["mean_ms"] * 100 if wb["mean_ms"] else float("nan")
    total_attempts = int(S["attempts"].sum())
    total_errors = int(S["errors"].sum())
    r1 = imp[cmax]
    s += [P("9. Анализ и расчёты", H1),
          P("Для каждой конфигурации сравнивается медиана трёх запусков. Относительное улучшение P95: "
            "(P95(до) − P95(после)) / P95(до) × 100 %. Отдельно приведено улучшение по "
            "P95, рассчитанному по объединённым сырым задержкам трёх повторов (P95 отдельных запусков не усредняются)."),
          P(f"Пример для {cmax} клиентов: ({ms(r1['p95_before'])} − {ms(r1['p95_after'])}) / {ms(r1['p95_before'])} "
            f"× 100 % = <b>{r1['p95_improvement_pct']:.2f} %</b>."),
          P("Таблица 5 — эффект индекса по медианам", TCAP), table(irows, cw3), Spacer(1, 6),
          P(f"Доля ошибок = ошибки / все попытки × 100 % = {total_errors} / {total_attempts} × 100 % = "
            f"<b>{total_errors / total_attempts * 100:.2f} %</b> (по каждой конфигурации — в таблице 4)."),
          P(f"<b>Стоимость записи.</b> Вставка {wb['docs']} документов по одному в отдельную тестовую коллекцию "
            f"{v['collection']}_write_test (основной набор не меняется): без индекса — в среднем {ms(wb['mean_ms'])} мс "
            f"(P95 {ms(wb['p95_ms'])} мс), с индексом — {ms(wi['mean_ms'])} мс (P95 {ms(wi['p95_ms'])} мс), "
            f"т. е. запись подорожала на {w_growth:.0f} %, так как каждая вставка дополнительно обновляет "
            f"B-tree индекса. <b>Размер индекса</b> {v['index_name']}: {size(new_idx)}; суммарный размер индексов "
            f"коллекции вырос с {size(sz_b['totalIndexSize'])} до {size(sz_i['totalIndexSize'])}.")]

    # 10. Графики
    s += [P("10. Графики", H1),
          KeepTogether([Image(str(config.CHARTS_DIR / "p95_by_clients.png"), width=W, height=W * 4.2 / 7.2),
                        P("Рисунок 1 — P95 задержки AP-01 в зависимости от числа клиентов", CAPTION)]),
          KeepTogether([Image(str(config.CHARTS_DIR / "throughput_by_clients.png"), width=W, height=W * 4.2 / 7.2),
                        P("Рисунок 2 — пропускная способность AP-01 в зависимости от числа клиентов", CAPTION)])]

    # 11. Интерпретация
    def growth(df, col):
        return df.loc[cmax, col] / df.loc[cmin, col]
    rps_b, rps_i = growth(base, "rps_median"), growth(idx, "rps_median")
    p95_b, p95_i = growth(base, "p95_median"), growth(idx, "p95_median")
    slo_b = base.loc[cmax, "p95_median"] <= env["slo_p95_ms"] and base.loc[cmax, "error_rate_pct"] <= env["slo_error_rate_pct"]
    slo_i = idx.loc[cmax, "p95_median"] <= env["slo_p95_ms"] and idx.loc[cmax, "error_rate_pct"] <= env["slo_error_rate_pct"]
    plateau_txt = ("не растёт и даже немного снижается" if rps_b < 1.0 else "почти не растёт" if rps_b < 1.3 else f"растёт лишь в {rps_b:.1f} раза")
    s += [P("11. Интерпретация результатов", H1),
          P(f"Без индекса каждый запрос AP-01 выполняет COLLSCAN по {b01['totalDocsExamined']} документам, поэтому "
            f"работа на запрос велика. При увеличении числа клиентов с {cmin} до {cmax} пропускная способность "
            f"{plateau_txt} (×{rps_b:.2f}), а P95 увеличивается в {p95_b:.1f} раза: система вышла на плато. "
            f"С индексом запрос читает только {i01['totalKeysExamined']} ключей и {i01['totalDocsExamined']} документов; "
            f"RPS при {cmax} клиентах выше в {r1['rps_gain_x']:.1f} раза, P95 ниже на {r1['p95_improvement_pct']:.2f} %, "
            f"при этом P95 с ростом нагрузки меняется лишь в {p95_i:.1f} раза. Разброс трёх повторов (бледные "
            "точки на графиках) много меньше эффекта индекса, поэтому разница не объясняется шумом."),
          P("<b>Почему throughput выходит на плато, а P95 растёт.</b> В closed-loop тесте каждый клиент отправляет "
            "следующий запрос только после ответа на предыдущий. Пока ресурс (ядра CPU сервера, а в Python-клиенте "
            f"также GIL; на стенде {env['cpu_count']} логических CPU) не загружен, добавление клиентов увеличивает RPS. "
            "Когда узкое место загружено полностью, сервер не может обработать больше запросов в секунду, и "
            "дополнительные клиенты лишь стоят в очереди. По закону Литтла N = X · R (клиенты = пропускная "
            "способность × время ответа): при постоянном X рост N полностью переходит в рост времени ответа R, "
            "особенно в хвосте распределения (P95/P99), где запрос ждёт за несколькими другими."),
          P(f"<b>Проверка SLO</b> (P95 ≤ {env['slo_p95_ms']:g} мс при {cmax} клиентах, ошибки ≤ "
            f"{env['slo_error_rate_pct']:g} %): без индекса — <b>{'выполнен' if slo_b else 'не выполнен'}</b> "
            f"(P95 = {ms(base.loc[cmax, 'p95_median'])} мс), с индексом — <b>{'выполнен' if slo_i else 'не выполнен'}</b> "
            f"(P95 = {ms(idx.loc[cmax, 'p95_median'])} мс).")]

    # 12. Ограничения
    lim = [f"Closed-loop генератор: нагрузка зависит от времени ответа, поэтому при деградации системы "
           "клиенты сами снижают темп (coordinated omission) и хвостовые задержки могут быть недооценены; "
           "это не open-loop тест с фиксированным RPS.",
           "Клиент и СУБД работают на одной машине и конкурируют за CPU; нет сетевых задержек реальной среды.",
           "Один и тот же фильтр во всех запросах: данные и индекс горячие в кэше; разные значения фильтра "
           "и холодный кэш дали бы иные цифры.",
           f"Объём данных мал ({env['n_docs']} документов) — весь набор помещается в память.",
           "Python-клиент ограничен GIL: часть роста задержки при 8 потоках — накладные расходы клиента."]
    if is_model:
        lim.insert(0, "Измерения выполнены на модели (локальное Python-хранилище), а не на MongoDB — "
                      "абсолютные значения задержек не переносятся на MongoDB; для итоговых чисел "
                      "эксперимент повторяется командой с BACKEND=mongo.")
    s += [P("12. Ограничения эксперимента", H1)] + [P(f"{i}) {t}") for i, t in enumerate(lim, 1)]

    # 13. Вывод
    s += [P("13. Вывод", H1),
          P(f"Разработан воспроизводимый benchmark-сценарий: фиксированный seed и SHA-256 набора данных, одинаковые "
            f"запросы и их число, отдельный прогрев, {env['repeats']} повтора на каждый уровень нагрузки "
            f"({', '.join(map(str, env['clients']))} клиентов), учёт ошибок, сохранение сырых данных в CSV и "
            "автоматическое построение графиков и отчёта. Гипотеза <b>подтверждена</b>: составной индекс "
            f"{{{f1}: 1, {f2}: 1}} сократил число просмотренных документов AP-01 с {b01['totalDocsExamined']} до "
            f"{i01['totalDocsExamined']}, снизил медианный P95 при {cmax} клиентах на {r1['p95_improvement_pct']:.2f} % "
            f"и увеличил пропускную способность в {r1['rps_gain_x']:.1f} раза; доля ошибок — "
            f"{total_errors / total_attempts * 100:.2f} %. Цена оптимизации — дополнительное место под индекс "
            f"({size(new_idx)}) и более дорогая запись (+{w_growth:.0f} % ко времени вставки), что приемлемо для "
            f"сценария «{v['name']}», где чтение по этому фильтру преобладает над записью.")]

    # 14. Контрольные вопросы
    qa = [("Чем throughput отличается от числа клиентов?",
           "Число клиентов — это параллелизм нагрузки (сколько запросов одновременно в работе), throughput — "
           "сколько запросов система реально завершает в секунду. Они связаны законом Литтла X = N / R."),
          ("Почему P95 важнее одного среднего?",
           "Среднее скрывает хвост: редкие медленные запросы почти не сдвигают его, но их видят пользователи. P95 "
           "показывает время, в которое укладываются 95 % запросов, и годится для SLO."),
          ("Какие показатели возвращает explain(\"executionStats\")?",
           "winningPlan (дерево стадий COLLSCAN/IXSCAN/FETCH/LIMIT), nReturned, totalKeysExamined, "
           "totalDocsExamined, executionTimeMillis и статистику по каждой стадии."),
          ("Зачем выполнять warm-up?",
           "Чтобы прогреть кэш СУБД, пул соединений и интерпретатор: иначе первые медленные запросы исказят процентили."),
          ("Почему нельзя менять индекс и объём данных одновременно?",
           "Тогда эффект нельзя приписать одной причине. Меняем один фактор, остальные (seed, данные, запросы) фиксируем."),
          ("Что означает выход throughput на плато?",
           "Узкое место (CPU, диск, блокировки, GIL клиента) загружено полностью; новые клиенты лишь удлиняют очередь и P95."),
          ("Какие ограничения у closed-loop benchmark?",
           "Темп нагрузки зависит от ответов системы (coordinated omission), нельзя задать целевой RPS, хвосты "
           "недооцениваются; клиент на той же машине конкурирует за ресурсы."),
          ("Как доказать воспроизводимость?",
           "Фиксированный seed и хэш набора, версии ПО в протоколе, скрипты и requirements.txt в репозитории, "
           "сырые CSV, 3 повтора с малым разбросом; любой может повторить команды из README.")]
    s += [P("Приложение. Ответы на контрольные вопросы", H1)]
    s += [P(f"<b>{i}. {q}</b> {a}", NOIND) for i, (q, a) in enumerate(qa, 1)]

    s += [P("Источники", H1)] + [P(t, NOIND) for t in (
        "1. Силлабус дисциплины, лекция №12 и методические указания к лабораторной работе №12.",
        "2. MongoDB Explain Results. URL: https://www.mongodb.com/docs/manual/reference/explain-results/",
        "3. MongoDB Database Profiler. URL: https://www.mongodb.com/docs/manual/tutorial/manage-the-database-profiler/",
        "4. Kleppmann M. Designing Data-Intensive Applications. O’Reilly, 2017.")]

    def footer(canvas, doc):
        if doc.page > 1:
            canvas.setFont("Serif", 12)
            canvas.drawCentredString(A4[0] / 2, 1.2 * cm, str(doc.page))

    doc = SimpleDocTemplate(str(config.REPORT_PDF), pagesize=A4, leftMargin=3 * cm, rightMargin=1.5 * cm,
                            topMargin=2 * cm, bottomMargin=2 * cm,
                            title="Лабораторная работа №12 — воспроизводимый benchmark NoSQL")
    doc.build(s, onFirstPage=footer, onLaterPages=footer)
    print(f"Отчёт: {config.REPORT_PDF}")


def _dom(dm):
    return f"{dm['min']}..{dm['max']}" if dm["type"] == "int" else ", ".join(dm["values"])


def _jsv(x):
    return f'"{x}"' if isinstance(x, str) else str(x)


def _js(q):
    return "{" + ", ".join(f"{k}: {_jsv(val)}" for k, val in q.items()) + "}"


def _ratio(e):
    return f"{e['totalDocsExamined'] / e['nReturned']:.1f}" if e["nReturned"] else "—"


if __name__ == "__main__":
    build()
