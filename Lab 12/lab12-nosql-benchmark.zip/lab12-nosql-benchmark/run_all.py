"""Полный цикл одной командой: данные -> benchmark -> анализ -> отчёт.

Запуск:  python run_all.py
"""
import subprocess
import sys

for step in ("seed.py", "benchmark.py", "analyze.py", "make_report.py"):
    print(f"\n>>> python {step}")
    subprocess.run([sys.executable, step], check=True)
