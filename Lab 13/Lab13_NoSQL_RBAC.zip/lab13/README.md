# Лабораторная работа №13. Настройка ролей и проверка минимальных привилегий

**Дисциплина:** Проектирование и применение NoSQL-технологий
**Вариант:** 2 — «Библиотека» (рабочая коллекция `books`, защищённая `loans`, журнал `audit_events`)
**Студент:** <ФИО>, группа ИС 24-21 · **Преподаватель:** <ФИО>
Алматинский технологический университет, 2026

Полный отчёт в формате Word: [`report/Lab13_Otchet.docx`](report/Lab13_Otchet.docx)

## Структура репозитория

| Файл | Назначение |
|---|---|
| `docker-compose.yml` | Стенд MongoDB 7 с авторизацией, порт только на 127.0.0.1 |
| `.env.example` | Шаблон учётных данных администратора (настоящий `.env` в Git не попадает) |
| `.gitignore` | Исключает `.env` и историю команд |
| `scripts/01_seed.js` | Учебная БД и синтетические данные (12 книг, 10 выдач, 5 событий) |
| `scripts/02_roles_users.js` | Пользовательские роли и пользователи (пароль — `passwordPrompt()`) |
| `scripts/03_least_privilege_check.js` | Проверка ролей по матрице доступа и исправление избыточной роли |
| `tests/test_*.js` | 16 позитивных и негативных тестов для viewer13, editor13, auditor13 |
| `screenshots/` | Скриншоты выполнения |
| `report/` | Отчёт .docx |


## 1. Цель работы

Применить принцип минимальных привилегий (least privilege) в учебной MongoDB: настроить ролевой доступ (RBAC) с привилегиями на уровне отдельных коллекций и доказать его корректность положительными и отрицательными тестами.

Вариант: 2 — «Библиотека». Рабочая коллекция — books (каталог книг), защищённая коллекция — loans (выдачи книг читателям), отдельный журнал — audit_events.


## 2. Описание стенда

| Параметр | Значение |
|---|---|
| СУБД | MongoDB Community Server 7 (Docker-образ mongo:7), авторизация включена |
| Клиент | mongosh |
| Сеть | порт 27017 опубликован только на 127.0.0.1 (доступ с локальной машины) |
| Учебная БД | university_lab13 |
| Администратор | labadmin (authenticationDatabase: admin); пароль задаётся в локальном .env, в Git не попадает |
| Учебные пользователи | viewer13, editor13, auditor13 (authenticationDatabase: university_lab13); пароли вводятся интерактивно через passwordPrompt() |
| Данные | синтетические: books — 12 документов, loans — 10, audit_events — 5 |

Стенд запускается командой docker compose up -d (файл docker-compose.yml). Начальные учётные данные администратора берутся из файла .env, который создаётся из шаблона .env.example и исключён из репозитория через .gitignore. После запуска выполнен повторный вход администратором, чтобы убедиться, что авторизация работает.


## 3. Модель угроз

Защищаемый актив — коллекция loans: она связывает читательские билеты с выданными книгами и датами, то есть содержит сведения о поведении читателей; журнал audit_events важен для расследования инцидентов. Основные угрозы: сотрудник с ролью просмотра каталога или редактор каталога читает или изменяет выдачи (нарушение конфиденциальности и целостности); компрометация учётной записи editor13 приводит к доступу ко всей базе, если роль выдана на БД целиком; нарушитель удаляет или подделывает записи audit_events, чтобы скрыть свои действия. Контрмеры: включённая аутентификация, пользовательские роли с привилегиями только на нужные коллекции и действия, аудитор только читает журнал и не может его менять, секреты не хранятся в коде и отчёте.


## 4. Матрица доступа

| Роль (пользователь) | books | loans | audit_events |
|---|---|---|---|
| viewer — bookViewer (viewer13) | чтение (find) | нет доступа | нет доступа |
| editor — bookEditor (editor13) | чтение/запись (find, insert, update, remove) | нет доступа | нет доступа |
| auditor — eventAuditor (auditor13) | нет доступа | нет доступа | чтение (find) |

Запрещённые операции для каждой роли: viewer — любые изменения books, любые операции с loans и audit_events; editor — любые операции с loans и audit_events; auditor — изменение и удаление audit_events, любые операции с books и loans.


## 5. Порядок выполнения

1. Подготовлен стенд: cp .env.example .env (пароль задан локально), docker compose up -d, проверен вход администратора.
2. Создана учебная БД и данные варианта: скрипт scripts/01_seed.js (books — 12, loans — 10, audit_events — 5 документов).
3. Спроектирована матрица доступа (раздел 4).
4. Созданы роли и пользователи: скрипт scripts/02_roles_users.js (раздел 6).
5. Выполнены позитивные и негативные тесты под каждым пользователем в отдельной сессии mongosh: tests/test_viewer13.js, tests/test_editor13.js, tests/test_auditor13.js (раздел 7).
6. Проверен принцип минимальных привилегий и продемонстрировано исправление избыточной роли: scripts/03_least_privilege_check.js (раздел 9).

```js
# 1. Стенд
cp .env.example .env          # задать пароль локально
docker compose up -d
mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p

# 2-4. Данные, роли и пользователи (под администратором)
mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/01_seed.js
mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/02_roles_users.js

# 5. Тесты (каждый пользователь - отдельная сессия)
mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u viewer13  -p --file tests/test_viewer13.js
mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u editor13  -p --file tests/test_editor13.js
mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u auditor13 -p --file tests/test_auditor13.js

# 6. Проверка least privilege (под администратором)
mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/03_least_privilege_check.js
```

Флаг -p без значения заставляет mongosh запросить пароль интерактивно, поэтому пароль не попадает в историю команд и на скриншоты.


## 6. Команды создания ролей и пользователей (секреты удалены)

```js
use university_lab13

db.createRole({role:"bookViewer",
  privileges:[{resource:{db:"university_lab13",collection:"books"},
               actions:["find"]}], roles:[]})

db.createRole({role:"bookEditor",
  privileges:[{resource:{db:"university_lab13",collection:"books"},
               actions:["find","insert","update","remove"]}], roles:[]})

db.createRole({role:"eventAuditor",
  privileges:[{resource:{db:"university_lab13",collection:"audit_events"},
               actions:["find"]}], roles:[]})

db.createUser({user:"viewer13",  pwd:passwordPrompt(),
  roles:[{role:"bookViewer",   db:"university_lab13"}]})
db.createUser({user:"editor13",  pwd:passwordPrompt(),
  roles:[{role:"bookEditor",   db:"university_lab13"}]})
db.createUser({user:"auditor13", pwd:passwordPrompt(),
  roles:[{role:"eventAuditor", db:"university_lab13"}]})
```

Все привилегии заданы на конкретную коллекцию (resource.collection), а не на всю базу. Роли не наследуют встроенные роли (roles: []). Вместо пароля в командах используется passwordPrompt().


## 7. Таблица тестов

Проведено 16 проверок: 6 разрешённых и 10 запрещённых (требование — не менее 4 + 4). Для негативного теста ошибка Unauthorized — ожидаемый успешный результат.

| № | Пользователь | Действие | Ожидаемый результат | Фактический результат | Вывод |
|---|---|---|---|---|---|
| T1 | viewer13 | `books.findOne({bookId:2001})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T2 | viewer13 | `books.insertOne({bookId:2099})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T3 | viewer13 | `loans.findOne({loanId:3001})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T4 | viewer13 | `audit_events.findOne()` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T5 | editor13 | `books.findOne({bookId:2002})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T6 | editor13 | `books.insertOne({bookId:2099})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T7 | editor13 | `books.updateOne({bookId:2099},{$set:{copies:2}})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T8 | editor13 | `books.deleteOne({bookId:2099})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T9 | editor13 | `loans.findOne({loanId:3001})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T10 | editor13 | `loans.insertOne({loanId:3099})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T11 | editor13 | `audit_events.findOne()` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T12 | auditor13 | `audit_events.findOne({event:'seed'})` | Разрешено | Выполнено, документ получен/изменён | PASS — доступ есть |
| T13 | auditor13 | `audit_events.insertOne({event:'fake'})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T14 | auditor13 | `audit_events.deleteOne({event:'seed'})` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T15 | auditor13 | `books.findOne()` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |
| T16 | auditor13 | `loans.findOne()` | Unauthorized | MongoServerError: not authorized (code 13, Unauthorized) | PASS — доступ запрещён |

Итог: 16 из 16 проверок — PASS. Каждая учётная запись выполняет только операции, предусмотренные матрицей доступа; все остальные операции отклоняются сервером с кодом 13 (Unauthorized).


## 8. Скриншоты

![Рисунок 1 — Роли и пользователи созданы (вывод scripts/02_roles_users.js, без паролей)](screenshots/01_roles_users.png)

*Рисунок 1 — Роли и пользователи созданы (вывод scripts/02_roles_users.js, без паролей)*

![Рисунок 2 — Тесты viewer13: успешное чтение books и ошибки Unauthorized](screenshots/02_viewer13.png)

*Рисунок 2 — Тесты viewer13: успешное чтение books и ошибки Unauthorized*

![Рисунок 3 — Тесты editor13: чтение/запись books и ошибки Unauthorized для loans и audit_events](screenshots/03_editor13.png)

*Рисунок 3 — Тесты editor13: чтение/запись books и ошибки Unauthorized для loans и audit_events*

![Рисунок 4 — Тесты auditor13: чтение audit_events и ошибки Unauthorized](screenshots/04_auditor13.png)

*Рисунок 4 — Тесты auditor13: чтение audit_events и ошибки Unauthorized*

![Рисунок 5 — Проверка минимальных привилегий и исправление роли librarianDraft](screenshots/05_least_privilege.png)

*Рисунок 5 — Проверка минимальных привилегий и исправление роли librarianDraft*


## 9. Проверка принципа минимальных привилегий


### 9.1. Бизнес-операции пользователя editor13 и минимальные действия

| Бизнес-операция | Действие MongoDB | Ресурс |
|---|---|---|
| Просмотр каталога, поиск книги | find | books |
| Добавление новой книги | insert | books |
| Исправление данных книги (тираж, год) | update | books |
| Списание книги из каталога | remove | books |
| Работа с выдачами — не входит в обязанности | — | loans: нет доступа |
| Просмотр журнала — не входит в обязанности | — | audit_events: нет доступа |


### 9.2. Права на всю базу или на коллекцию

Скрипт 03_least_privilege_check.js получает привилегии каждой роли через getRole(..., {showPrivileges:true}) и проверяет, что у каждой привилегии указано конкретное имя коллекции. Для bookViewer, bookEditor и eventAuditor ресурс — только books или audit_events; привилегий на всю БД (collection: "") и унаследованных ролей нет.


### 9.3. Запрет операций вне матрицы

Скрипт сравнивает действия каждой роли с матрицей доступа: лишних коллекций и лишних действий не найдено (результат «OK»). Практически запрет подтверждён негативными тестами T2–T4, T9–T11, T13–T16.


### 9.4. Исправление избыточной роли

Для демонстрации создана черновая роль librarianDraft для библиотекаря, которому нужно только просматривать каталог, добавлять и править книги. В ней допущены две ошибки: лишнее действие remove на books и доступ find к защищённой коллекции loans. Исправление выполнено без пересоздания роли:

```js
db.revokePrivilegesFromRole("librarianDraft", [
  { resource:{db:"university_lab13", collection:"books"}, actions:["remove"] },
  { resource:{db:"university_lab13", collection:"loans"}, actions:["find"] }
])
// ДО:    books [find, insert, update, remove], loans [find]
// ПОСЛЕ: books [find, insert, update]
```

Аналогично исправляется роль, выданная как встроенная readWrite на всю БД: её заменяют пользовательской ролью с привилегиями на нужную коллекцию (revokeRolesFromUser + grantRolesToUser).


## 10. Вывод

Настроенная модель доступа соответствует принципу минимальных привилегий: каждая из трёх ролей получила только те действия и только на той коллекции, которые нужны для её задачи; защищённая коллекция loans недоступна ни одной из учебных ролей, а журнал audit_events доступен аудитору только для чтения. Это подтверждено 16 тестами (6 позитивных, 10 негативных) и автоматической проверкой привилегий ролей. Аутентификация (кто подключился) и авторизация (что ему разрешено) разделены: вход выполняется по паролю, а набор операций определяется ролью.

Рекомендации по улучшению: разделить роль editor на «добавление/правку» и отдельную роль «списание» (remove), если списание выполняют не все редакторы; включить TLS и SCRAM-SHA-256 для подключений; в производственной среде использовать журнал аудита MongoDB Enterprise или внешнее хранилище логов, недоступное для изменения; регулярно пересматривать роли командой rolesInfo; хранить секреты в менеджере секретов, а не в файлах; ограничить вход по IP (authenticationRestrictions).


## 11. Ответы на контрольные вопросы

**1. Чем аутентификация отличается от авторизации?**
Аутентификация проверяет, кто подключился (логин и пароль, механизм SCRAM). Авторизация определяет, что этому пользователю разрешено делать — через роли и привилегии.

**2. Что такое RBAC и принцип минимальных привилегий?**
RBAC — модель, в которой права выдаются не пользователю напрямую, а роли, а пользователю назначается роль. Принцип минимальных привилегий: роль получает только те действия и ресурсы, без которых задача не может быть выполнена.

**3. Зачем нужны негативные тесты доступа?**
Позитивный тест показывает только, что нужная операция работает. Негативный тест доказывает, что лишние операции действительно запрещены; без него избыточные права остаются незамеченными.

**4. Почему роль readWrite на всю БД может быть избыточной?**
readWrite даёт чтение и запись во все коллекции базы, включая защищённые (loans, grades), а также создание и удаление коллекций и индексов. Пользователю, работающему с одной коллекцией, это не нужно, а при компрометации учётной записи ущерб будет максимальным.

**5. Как не раскрывать секреты при демонстрации?**
Вводить пароли интерактивно (-p без значения, passwordPrompt()), хранить их в .env, исключённом из Git, не показывать на скриншотах, не публиковать историю команд, использовать в шаблонах плейсхолдеры.

**6. Какие действия включает пользовательская роль MongoDB?**
Те, что явно перечислены в privileges: ресурс (db и collection) и список actions — например find, insert, update, remove, а также createIndex, dropCollection и др. Дополнительно роль может наследовать другие роли через поле roles.

**7. Как исправить обнаруженную избыточную привилегию?**
Отозвать лишние действия командой revokePrivilegesFromRole (или переопределить роль через updateRole), лишнюю роль у пользователя — revokeRolesFromUser; затем повторить негативные тесты и убедиться, что операция теперь возвращает Unauthorized.


## 12. Источники

1. Силлабус «Проектирование и применение NoSQL-технологий», 2026–2027, лабораторная работа №13.
2. MongoDB Manual: Role-Based Access Control — https://www.mongodb.com/docs/manual/core/authorization/
3. MongoDB Manual: Create a User — https://www.mongodb.com/docs/manual/tutorial/create-users/
4. MongoDB Manual: User-Defined Roles — https://www.mongodb.com/docs/manual/core/authorization/#user-defined-roles
