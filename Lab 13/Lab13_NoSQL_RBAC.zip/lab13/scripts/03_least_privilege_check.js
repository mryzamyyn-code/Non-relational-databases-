// Проверка принципа минимальных привилегий (раздел 9 методички).
// Запуск (админ): mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/03_least_privilege_check.js
const lab = db.getSiblingDB("university_lab13");
const DB = "university_lab13";

// Разрешённое по матрице доступа: роль -> { коллекция: [действия] }
const matrix = {
  bookViewer:   { books: ["find"] },
  bookEditor:   { books: ["find", "insert", "update", "remove"] },
  eventAuditor: { audit_events: ["find"] }
};

print("=== 9.2–9.3. Проверка ролей по матрице доступа ===");
Object.keys(matrix).forEach(role => {
  const info = lab.getRole(role, { showPrivileges: true });
  const problems = [];
  if (info.roles.length) problems.push("наследует роли: " + JSON.stringify(info.roles));
  info.privileges.forEach(p => {
    const coll = p.resource.collection;
    if (coll === "" || coll === undefined) problems.push("привилегия на ВСЮ БД, а не на коллекцию");
    else if (!matrix[role][coll]) problems.push("лишний доступ к коллекции " + coll);
    else p.actions.forEach(a => { if (!matrix[role][coll].includes(a)) problems.push("лишнее действие " + a + " на " + coll); });
  });
  print(`${role}: ` + JSON.stringify(info.privileges.map(p => ({ collection: p.resource.collection, actions: p.actions }))));
  print("  -> " + (problems.length ? "НАРУШЕНИЕ: " + problems.join("; ") : "OK — только коллекции и действия из матрицы"));
});

print("\n=== 9.4. Демонстрация исправления избыточной роли ===");
// Черновая роль библиотекаря: бизнес-операции — смотреть каталог, добавлять и править книги.
// Ошибки проектирования: лишнее действие remove и доступ к защищённой коллекции loans.
try { lab.dropRole("librarianDraft"); } catch (e) {}
lab.createRole({
  role: "librarianDraft",
  privileges: [
    { resource: { db: DB, collection: "books" }, actions: ["find", "insert", "update", "remove"] },
    { resource: { db: DB, collection: "loans" }, actions: ["find"] }
  ],
  roles: []
});
print("ДО:    " + JSON.stringify(lab.getRole("librarianDraft", { showPrivileges: true }).privileges.map(p => ({ c: p.resource.collection, a: p.actions }))));

// Исправление: отзываем лишние привилегии, не пересоздавая роль
lab.revokePrivilegesFromRole("librarianDraft", [
  { resource: { db: DB, collection: "books" }, actions: ["remove"] },
  { resource: { db: DB, collection: "loans" }, actions: ["find"] }
]);
print("ПОСЛЕ: " + JSON.stringify(lab.getRole("librarianDraft", { showPrivileges: true }).privileges.map(p => ({ c: p.resource.collection, a: p.actions }))));

lab.dropRole("librarianDraft");   // демо-роль удаляется, на стенде остаются только роли работы
print("Демо-роль librarianDraft удалена.");
