// Лабораторная работа №13, вариант 2 «Библиотека»
// Заполнение учебной БД синтетическими данными.
// Запуск (из административной сессии, пароль вводится интерактивно):
//   mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/01_seed.js

const lab = db.getSiblingDB("university_lab13");

// Очистка только учебных коллекций — для воспроизводимости
["books", "loans", "audit_events"].forEach(c => lab.getCollection(c).drop());

// Рабочая коллекция: книги (12 документов, вымышленные данные)
lab.books.insertMany([
  { bookId: 2001, title: "Основы NoSQL",              author: "А. Сериков",    year: 2021, genre: "IT",         copies: 5 },
  { bookId: 2002, title: "Проектирование баз данных", author: "Д. Ахметова",   year: 2019, genre: "IT",         copies: 3 },
  { bookId: 2003, title: "Алгоритмы на практике",     author: "Е. Жумабаев",   year: 2020, genre: "IT",         copies: 4 },
  { bookId: 2004, title: "История Великой степи",     author: "К. Нурланов",   year: 2018, genre: "История",    copies: 2 },
  { bookId: 2005, title: "Линейная алгебра",          author: "М. Оспанова",   year: 2017, genre: "Математика", copies: 6 },
  { bookId: 2006, title: "Информационная безопасность", author: "Р. Касымов",  year: 2022, genre: "IT",         copies: 4 },
  { bookId: 2007, title: "Сети ЭВМ",                  author: "С. Бекова",     year: 2016, genre: "IT",         copies: 3 },
  { bookId: 2008, title: "Сказки народов мира",       author: "Т. Алиева",     year: 2015, genre: "Литература", copies: 7 },
  { bookId: 2009, title: "Физика для инженеров",      author: "У. Тлеуов",     year: 2019, genre: "Физика",     copies: 2 },
  { bookId: 2010, title: "Экономика предприятия",     author: "Ф. Садыкова",   year: 2021, genre: "Экономика",  copies: 3 },
  { bookId: 2011, title: "Python для начинающих",     author: "Х. Ермеков",    year: 2023, genre: "IT",         copies: 8 },
  { bookId: 2012, title: "Статистика и данные",       author: "Ш. Мукашева",   year: 2020, genre: "Математика", copies: 2 }
]);

// Защищённая коллекция: выдачи книг читателям (10 документов, вымышленные читатели)
lab.loans.insertMany([
  { loanId: 3001, bookId: 2001, readerCard: "R-0101", issued: ISODate("2026-09-02"), due: ISODate("2026-09-16"), returned: true  },
  { loanId: 3002, bookId: 2003, readerCard: "R-0102", issued: ISODate("2026-09-05"), due: ISODate("2026-09-19"), returned: true  },
  { loanId: 3003, bookId: 2005, readerCard: "R-0103", issued: ISODate("2026-09-10"), due: ISODate("2026-09-24"), returned: false },
  { loanId: 3004, bookId: 2011, readerCard: "R-0104", issued: ISODate("2026-10-01"), due: ISODate("2026-10-15"), returned: true  },
  { loanId: 3005, bookId: 2006, readerCard: "R-0105", issued: ISODate("2026-10-03"), due: ISODate("2026-10-17"), returned: false },
  { loanId: 3006, bookId: 2002, readerCard: "R-0101", issued: ISODate("2026-10-12"), due: ISODate("2026-10-26"), returned: true  },
  { loanId: 3007, bookId: 2008, readerCard: "R-0106", issued: ISODate("2026-10-20"), due: ISODate("2026-11-03"), returned: false },
  { loanId: 3008, bookId: 2012, readerCard: "R-0107", issued: ISODate("2026-11-01"), due: ISODate("2026-11-15"), returned: false },
  { loanId: 3009, bookId: 2004, readerCard: "R-0108", issued: ISODate("2026-11-05"), due: ISODate("2026-11-19"), returned: true  },
  { loanId: 3010, bookId: 2010, readerCard: "R-0109", issued: ISODate("2026-11-10"), due: ISODate("2026-11-24"), returned: false }
]);

// Отдельный журнал для аудитора
lab.audit_events.insertMany([
  { event: "seed",          source: "lab",   ts: new Date() },
  { event: "book_added",    source: "admin", bookId: 2011, ts: new Date() },
  { event: "loan_issued",   source: "admin", loanId: 3010, ts: new Date() },
  { event: "role_created",  source: "admin", role: "bookViewer", ts: new Date() },
  { event: "login_failed",  source: "auth",  user: "unknown", ts: new Date() }
]);

print("books:        " + lab.books.countDocuments());
print("loans:        " + lab.loans.countDocuments());
print("audit_events: " + lab.audit_events.countDocuments());
