// Лабораторная работа №13, вариант 2 «Библиотека»
// Создание пользовательских ролей (привилегии на уровне КОЛЛЕКЦИЙ) и учебных пользователей.
// Пароли НЕ хранятся в коде: passwordPrompt() запрашивает их интерактивно.
// Запуск:
//   mongosh --host 127.0.0.1 --authenticationDatabase admin -u labadmin -p --file scripts/02_roles_users.js

const lab = db.getSiblingDB("university_lab13");
const DB = "university_lab13";

// Повторный запуск: удаляем только учебные роли/пользователей этой работы
["viewer13", "editor13", "auditor13"].forEach(u => { try { lab.dropUser(u); } catch (e) {} });
["bookViewer", "bookEditor", "eventAuditor"].forEach(r => { try { lab.dropRole(r); } catch (e) {} });

// viewer — только чтение рабочей коллекции books
lab.createRole({
  role: "bookViewer",
  privileges: [ { resource: { db: DB, collection: "books" }, actions: ["find"] } ],
  roles: []
});

// editor — чтение/запись рабочей коллекции books
lab.createRole({
  role: "bookEditor",
  privileges: [ { resource: { db: DB, collection: "books" }, actions: ["find", "insert", "update", "remove"] } ],
  roles: []
});

// auditor — только чтение журнала audit_events
lab.createRole({
  role: "eventAuditor",
  privileges: [ { resource: { db: DB, collection: "audit_events" }, actions: ["find"] } ],
  roles: []
});

// Пользователи: пароль вводится с клавиатуры для каждого
print("Пароль для viewer13:");
lab.createUser({ user: "viewer13",  pwd: passwordPrompt(), roles: [ { role: "bookViewer",   db: DB } ] });
print("Пароль для editor13:");
lab.createUser({ user: "editor13",  pwd: passwordPrompt(), roles: [ { role: "bookEditor",   db: DB } ] });
print("Пароль для auditor13:");
lab.createUser({ user: "auditor13", pwd: passwordPrompt(), roles: [ { role: "eventAuditor", db: DB } ] });

print("Роли и пользователи созданы.");
printjson(lab.getUsers({ showCredentials: false }).users.map(u => ({ user: u.user, roles: u.roles })));
