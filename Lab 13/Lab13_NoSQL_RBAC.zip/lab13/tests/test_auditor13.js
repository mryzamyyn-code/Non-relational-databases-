// Запуск: mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u auditor13 -p --file tests/test_auditor13.js
// --- Помощник: выполнить операцию, поймать ошибку, сравнить с ожидаемым ---
// Каждый тест: выполнить операцию, поймать ошибку, сравнить с ожидаемым результатом.
const lab = db.getSiblingDB("university_lab13");
const results = [];

function check(id, user, action, expected, fn) {
  let actual, ok;
  try {
    fn();
    actual = "Выполнено";
    ok = expected === "allowed";
  } catch (e) {
    actual = (e.code === 13 || e.codeName === "Unauthorized")
      ? "Unauthorized (code 13)"
      : "Ошибка: " + e.message;
    ok = expected === "denied" && (e.code === 13 || e.codeName === "Unauthorized");
  }
  const exp = expected === "allowed" ? "Разрешено" : "Unauthorized";
  results.push({ id, user, action, expected: exp, actual, verdict: ok ? "PASS" : "FAIL" });
}

function report() {
  print("\n| № | Пользователь | Действие | Ожидаемый | Фактический | Вывод |");
  print("|---|---|---|---|---|---|");
  results.forEach(r =>
    print(`| ${r.id} | ${r.user} | \`${r.action}\` | ${r.expected} | ${r.actual} | ${r.verdict} |`));
  const fails = results.filter(r => r.verdict === "FAIL").length;
  print(`\nИтого: ${results.length - fails}/${results.length} PASS`);
}
// --- Тесты ---
const u = "auditor13";
check("T12", u, "audit_events.findOne({event:'seed'})",   "allowed", () => { if (!lab.audit_events.findOne({ event: "seed" })) throw new Error("документ не найден"); });
check("T13", u, "audit_events.insertOne({event:'fake'})", "denied",  () => lab.audit_events.insertOne({ event: "fake" }));
check("T14", u, "audit_events.deleteOne({event:'seed'})", "denied",  () => lab.audit_events.deleteOne({ event: "seed" }));
check("T15", u, "books.findOne()",                        "denied",  () => lab.books.findOne());
check("T16", u, "loans.findOne()",                        "denied",  () => lab.loans.findOne());
report();
