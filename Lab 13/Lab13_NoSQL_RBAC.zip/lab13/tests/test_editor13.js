// Запуск: mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u editor13 -p --file tests/test_editor13.js
// --- Помощник: выполнить операцию, поймать ошибку, сравнить с ожидаемым ---
// Каждый тест: выполнить операцию, поймать ошибку, сравнить с ожидаемым результатом.
const lab = db.getSiblingDB("university_lab13");
const results = [];

function check(id, user, action, expected, fn) {
  let actual, ok;
  try {
    fn();
    actual = "Выполнено";
    ok = expected === "allowed";
  } catch (e) {
    actual = (e.code === 13 || e.codeName === "Unauthorized")
      ? "Unauthorized (code 13)"
      : "Ошибка: " + e.message;
    ok = expected === "denied" && (e.code === 13 || e.codeName === "Unauthorized");
  }
  const exp = expected === "allowed" ? "Разрешено" : "Unauthorized";
  results.push({ id, user, action, expected: exp, actual, verdict: ok ? "PASS" : "FAIL" });
}

function report() {
  print("\n| № | Пользователь | Действие | Ожидаемый | Фактический | Вывод |");
  print("|---|---|---|---|---|---|");
  results.forEach(r =>
    print(`| ${r.id} | ${r.user} | \`${r.action}\` | ${r.expected} | ${r.actual} | ${r.verdict} |`));
  const fails = results.filter(r => r.verdict === "FAIL").length;
  print(`\nИтого: ${results.length - fails}/${results.length} PASS`);
}
// --- Тесты ---
const u = "editor13";
check("T5",  u, "books.findOne({bookId:2002})",          "allowed", () => { if (!lab.books.findOne({ bookId: 2002 })) throw new Error("документ не найден"); });
check("T6",  u, "books.insertOne({bookId:2099})",        "allowed", () => lab.books.insertOne({ bookId: 2099, title: "Тестовая книга", year: 2026, copies: 1 }));
check("T7",  u, "books.updateOne({bookId:2099},{$set})", "allowed", () => lab.books.updateOne({ bookId: 2099 }, { $set: { copies: 2 } }));
check("T8",  u, "books.deleteOne({bookId:2099})",        "allowed", () => lab.books.deleteOne({ bookId: 2099 }));
check("T9",  u, "loans.findOne({loanId:3001})",          "denied",  () => lab.loans.findOne({ loanId: 3001 }));
check("T10", u, "loans.insertOne({loanId:3099})",        "denied",  () => lab.loans.insertOne({ loanId: 3099 }));
check("T11", u, "audit_events.findOne()",                "denied",  () => lab.audit_events.findOne());
report();
