// Запуск: mongosh --host 127.0.0.1 --authenticationDatabase university_lab13 -u viewer13 -p --file tests/test_viewer13.js
// --- Помощник: выполнить операцию, поймать ошибку, сравнить с ожидаемым ---
// Каждый тест: выполнить операцию, поймать ошибку, сравнить с ожидаемым результатом.
const lab = db.getSiblingDB("university_lab13");
const results = [];

function check(id, user, action, expected, fn) {
  let actual, ok;
  try {
    fn();
    actual = "Выполнено";
    ok = expected === "allowed";
  } catch (e) {
    actual = (e.code === 13 || e.codeName === "Unauthorized")
      ? "Unauthorized (code 13)"
      : "Ошибка: " + e.message;
    ok = expected === "denied" && (e.code === 13 || e.codeName === "Unauthorized");
  }
  const exp = expected === "allowed" ? "Разрешено" : "Unauthorized";
  results.push({ id, user, action, expected: exp, actual, verdict: ok ? "PASS" : "FAIL" });
}

function report() {
  print("\n| № | Пользователь | Действие | Ожидаемый | Фактический | Вывод |");
  print("|---|---|---|---|---|---|");
  results.forEach(r =>
    print(`| ${r.id} | ${r.user} | \`${r.action}\` | ${r.expected} | ${r.actual} | ${r.verdict} |`));
  const fails = results.filter(r => r.verdict === "FAIL").length;
  print(`\nИтого: ${results.length - fails}/${results.length} PASS`);
}
// --- Тесты ---
const u = "viewer13";
check("T1", u, "books.findOne({bookId:2001})",  "allowed", () => { if (!lab.books.findOne({ bookId: 2001 })) throw new Error("документ не найден"); });
check("T2", u, "books.insertOne({bookId:2099})", "denied", () => lab.books.insertOne({ bookId: 2099, title: "Test" }));
check("T3", u, "loans.findOne({loanId:3001})",  "denied",  () => lab.loans.findOne({ loanId: 3001 }));
check("T4", u, "audit_events.findOne()",        "denied",  () => lab.audit_events.findOne());
report();
