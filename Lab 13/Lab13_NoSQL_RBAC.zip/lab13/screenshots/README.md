# Скриншоты

Сделайте скриншоты окна терминала после запуска скриптов и сохраните сюда с этими именами
(на скриншотах не должно быть паролей — при `-p` пароль при вводе не отображается):

| Файл | Что на скриншоте |
|---|---|
| `01_roles_users.png` | вывод `scripts/02_roles_users.js` — созданные роли и пользователи |
| `02_viewer13.png` | вывод `tests/test_viewer13.js` — таблица T1–T4 |
| `03_editor13.png` | вывод `tests/test_editor13.js` — таблица T5–T11 |
| `04_auditor13.png` | вывод `tests/test_auditor13.js` — таблица T12–T16 |
| `05_least_privilege.png` | вывод `scripts/03_least_privilege_check.js` |

После этого скриншоты автоматически отобразятся в README.md на GitHub.
Те же картинки вставьте в `report/Lab13_Otchet.docx` вместо серых рамок.
