// =====================================================================
// Лабораторная работа №9. Создание графа в Neo4j и базовые запросы Cypher
// Вариант 2 — «Библиотека»
// Метки узлов: Reader, Book, Author.  Отношения: BORROWED, WROTE
// Целевой запрос: книги читателя и их авторы
// Все данные учебные, вымышленные.
// Выполнять в Neo4j Browser / Query последовательно, по одному запросу.
// =====================================================================

// ---------- 0. Проверка соединения и пустой базы ----------
RETURN 'Neo4j works' AS status;
MATCH (n) RETURN count(n) AS nodesBefore;
// Только для пустой УЧЕБНОЙ базы, если там остались данные прошлых работ:
// MATCH (n) DETACH DELETE n;

// ---------- Задание 2.1. Ограничения уникальности ----------
CREATE CONSTRAINT reader_id_unique IF NOT EXISTS
FOR (r:Reader) REQUIRE r.id IS UNIQUE;
CREATE CONSTRAINT book_id_unique IF NOT EXISTS
FOR (b:Book) REQUIRE b.id IS UNIQUE;
CREATE CONSTRAINT author_id_unique IF NOT EXISTS
FOR (a:Author) REQUIRE a.id IS UNIQUE;
SHOW CONSTRAINTS;

// ---------- Задание 2.2. Узлы (16 шт.: 5 Reader, 7 Book, 4 Author) ----------
MERGE (r1:Reader {id: 1}) SET r1.name = "Aibek",  r1.group = "IS-24-1", r1.course = 3
MERGE (r2:Reader {id: 2}) SET r2.name = "Aliya",  r2.group = "IS-24-1", r2.course = 3
MERGE (r3:Reader {id: 3}) SET r3.name = "Damir",  r3.group = "IS-24-2", r3.course = 3
MERGE (r4:Reader {id: 4}) SET r4.name = "Saule",  r4.group = "IS-25-1", r4.course = 2
MERGE (r5:Reader {id: 5}) SET r5.name = "Nurlan", r5.group = "IS-23-1", r5.course = 4

MERGE (b1:Book {id: 201}) SET b1.title = "Graph Databases in Practice", b1.genre = "IT",      b1.year = 2021, b1.pages = 320, b1.copies = 3
MERGE (b2:Book {id: 202}) SET b2.title = "NoSQL for Beginners",         b2.genre = "IT",      b2.year = 2019, b2.pages = 250, b2.copies = 5
MERGE (b3:Book {id: 203}) SET b3.title = "Steppe Legends",              b3.genre = "Fiction", b3.year = 2015, b3.pages = 410, b3.copies = 2
MERGE (b4:Book {id: 204}) SET b4.title = "Algorithms Explained",        b4.genre = "IT",      b4.year = 2020, b4.pages = 520, b4.copies = 4
MERGE (b5:Book {id: 205}) SET b5.title = "City of Mountains",           b5.genre = "Fiction", b5.year = 2018, b5.pages = 290, b5.copies = 2
MERGE (b6:Book {id: 206}) SET b6.title = "Data Modeling Patterns",      b6.genre = "IT",      b6.year = 2022, b6.pages = 380, b6.copies = 3
MERGE (b7:Book {id: 207}) SET b7.title = "Silent Garden",               b7.genre = "Poetry",  b7.year = 2023, b7.pages = 180, b7.copies = 1

MERGE (a1:Author {id: 301}) SET a1.name = "Aidar Seitkali", a1.country = "Kazakhstan", a1.birthYear = 1975
MERGE (a2:Author {id: 302}) SET a2.name = "Marina Orlova",  a2.country = "Russia",     a2.birthYear = 1982
MERGE (a3:Author {id: 303}) SET a3.name = "John Carter",    a3.country = "USA",        a3.birthYear = 1968
MERGE (a4:Author {id: 304}) SET a4.name = "Lena Tanaka",    a4.country = "Japan",      a4.birthYear = 1990;

// ---------- Задание 2.3. Отношения WROTE (8 шт.): Author -> Book ----------
UNWIND [
  [301, 203], [301, 205],
  [302, 202], [302, 206], [302, 201],
  [303, 201], [303, 204],
  [304, 207]
] AS pair
MATCH (a:Author {id: pair[0]}), (b:Book {id: pair[1]})
MERGE (a)-[:WROTE]->(b);

// ---------- Задание 2.4. Отношения BORROWED (12 шт.): Reader -> Book ----------
UNWIND [
  {r: 1, b: 201, d: "2026-09-03"}, {r: 1, b: 202, d: "2026-09-10"}, {r: 1, b: 203, d: "2026-10-01"},
  {r: 2, b: 202, d: "2026-09-05"}, {r: 2, b: 205, d: "2026-09-20"},
  {r: 3, b: 201, d: "2026-09-07"}, {r: 3, b: 204, d: "2026-09-12"}, {r: 3, b: 206, d: "2026-10-02"},
  {r: 4, b: 203, d: "2026-09-15"}, {r: 4, b: 207, d: "2026-10-05"},
  {r: 5, b: 204, d: "2026-09-18"}, {r: 5, b: 206, d: "2026-10-08"}
] AS row
MATCH (r:Reader {id: row.r}), (b:Book {id: row.b})
MERGE (r)-[br:BORROWED]->(b)
SET br.date = date(row.d);

// ---------- Проверка структуры графа ----------
MATCH (n) RETURN labels(n)[0] AS label, count(*) AS nodes ORDER BY label;
MATCH ()-[r]->() RETURN type(r) AS relType, count(*) AS rels ORDER BY relType;
MATCH (n) RETURN n;          // визуализация всего графа

// ---------- Задание 3. Чтение, сортировка, ограничение ----------
// Q1. Все узлы одной метки
MATCH (r:Reader) RETURN r;
// Q2. Выбранные свойства с сортировкой и LIMIT
MATCH (b:Book)
RETURN b.title AS book, b.year AS year, b.pages AS pages
ORDER BY year DESC LIMIT 5;

// ---------- Задание 4. Запросы по связям ----------
// Q3. Одношаговый переход: какие книги брал каждый читатель
MATCH (r:Reader)-[:BORROWED]->(b:Book)
RETURN r.name AS reader, b.title AS book
ORDER BY reader, book;
// Q4. Обратный поиск: кто брал книгу «Graph Databases in Practice»
MATCH (b:Book {id: 201})<-[:BORROWED]-(r:Reader)
RETURN b.title AS book, r.name AS reader
ORDER BY reader;
// Q5. Цепочка из двух отношений (целевой запрос варианта):
//     книги читателя и их авторы
MATCH (r:Reader {name: "Aibek"})-[:BORROWED]->(b:Book)<-[:WROTE]-(a:Author)
RETURN r.name AS reader, b.title AS book, collect(a.name) AS authors
ORDER BY book;

// ---------- Задание 5. Фильтрация WHERE ----------
// Q6. Строковый фильтр
MATCH (b:Book) WHERE b.genre = "IT"
RETURN b.title AS book, b.genre AS genre ORDER BY book;
// Q7. Числовой фильтр
MATCH (b:Book) WHERE b.pages >= 350
RETURN b.title AS book, b.pages AS pages ORDER BY pages DESC;

// ---------- Задание 6. Изменение свойств узла и отношения ----------
// Q8a. Свойство узла: выдали ещё один экземпляр книги 201
MATCH (b:Book {id: 201}) SET b.copies = b.copies - 1
RETURN b.title AS book, b.copies AS copies;
// Q8b. Свойство отношения: читатель 1 вернул книгу 201
MATCH (r:Reader {id: 1})-[br:BORROWED]->(b:Book {id: 201})
SET br.returned = true, br.returnDate = date("2026-09-24")
RETURN r.name AS reader, b.title AS book, br.date AS taken,
       br.returned AS returned, br.returnDate AS returnDate;
// Проверка изменений
MATCH (r:Reader {id: 1})-[br:BORROWED]->(b:Book)
RETURN b.title AS book, b.copies AS copies, br.returned AS returned
ORDER BY book;

// ---------- Задание 7. Безопасное удаление тестового узла ----------
CREATE (t:Temp {id: 999, note: "delete-me"});
MATCH (t:Temp {id: 999}), (b:Book {id: 207})
CREATE (t)-[:TEST_LINK]->(b);
MATCH (n:Temp {id: 999}) RETURN n;
MATCH (n:Temp {id: 999}) DETACH DELETE n;
MATCH (n:Temp {id: 999}) RETURN count(n) AS remaining;
MATCH ()-[l:TEST_LINK]->() RETURN count(l) AS remainingLinks;

// ---------- Задание 8. Повторный MERGE и проверка отсутствия дублей ----------
// 1) Ещё раз выполните блоки 2.2, 2.3 и 2.4 без изменений.
// 2) Проверьте количество:
MATCH (n) WHERE n:Reader OR n:Book OR n:Author
RETURN labels(n)[0] AS label, count(n) AS total, count(DISTINCT n.id) AS uniqueIds
ORDER BY label;
MATCH ()-[r]->() RETURN type(r) AS relType, count(*) AS rels ORDER BY relType;
// 3) Попытка создать дубль через CREATE отклоняется ограничением:
// CREATE (:Book {id: 201, title: "Duplicate"});
// -> Neo4j.ClientError.Schema.ConstraintValidationFailed

// ---------- Дополнительное задание. Общий сосед ----------
// Пары читателей, бравших одну и ту же книгу
MATCH (a:Reader)-[:BORROWED]->(b:Book)<-[:BORROWED]-(c:Reader)
WHERE a.id < c.id
RETURN a.name AS firstReader, c.name AS secondReader,
       collect(DISTINCT b.title) AS sharedBooks
ORDER BY firstReader, secondReader;
