# Скриншоты результатов

Сюда загружаются скриншоты из Neo4j Browser (номера совпадают с рисунками в отчёте):

| Файл | Запрос |
|---|---|
| 03_constraints.png | SHOW CONSTRAINTS |
| 04_counts.png | количество узлов и отношений |
| 05_full_graph.png | MATCH (n) RETURN n |
| 06_q1_readers.png | Q1 — все Reader |
| 07_q2_order_limit.png | Q2 — ORDER BY / LIMIT |
| 08_q3_one_hop.png | Q3 — одношаговый переход |
| 09_q4_reverse.png | Q4 — обратный поиск |
| 10_q5_two_hops.png | Q5 — книги читателя и их авторы |
| 11_q6_where_string.png | Q6 — WHERE по строке |
| 12_q7_where_number.png | Q7 — WHERE по числу |
| 13_q8_set.png | Q8 — SET узла и отношения |
| 14_delete.png | удаление Temp, remaining = 0 |
| 15_merge_again.png | повторный MERGE, нет дублей |
| 16_extra_shared.png | доп. задание — общие книги |
